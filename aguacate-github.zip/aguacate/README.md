# AGUACATE 🥑

Plataforma de torneos esports para República Dominicana.

## Stack

- **Next.js 15** + TypeScript
- **Tailwind CSS** + Framer Motion
- **PostgreSQL** + Prisma ORM
- **NextAuth v5** (Google, Discord, Email)

## Paleta Oficial

| Color | Hex |
|-------|-----|
| Spoon Blue | `#0057B8` |
| Spoon Yellow | `#FFD100` |
| White | `#FFFFFF` |
| Background | `#0A0D14` |

## Setup

```bash
# 1. Instalar dependencias
npm install

# 2. Copiar variables de entorno
cp .env.example .env
# → Editar .env con tus credenciales

# 3. Crear base de datos
npm run db:push

# 4. Iniciar en desarrollo
npm run dev
```

## Variables de entorno requeridas

```
DATABASE_URL=
AUTH_SECRET=
AUTH_GOOGLE_ID=
AUTH_GOOGLE_SECRET=
AUTH_DISCORD_ID=
AUTH_DISCORD_SECRET=
NEXT_PUBLIC_APP_URL=
```

## Estructura

```
src/
├── app/            # Pages (App Router)
├── components/     # UI + Layout + Feature components
├── lib/            # Prisma, Auth, Utils
├── types/          # TypeScript types
prisma/
└── schema.prisma   # DB schema completo
```
