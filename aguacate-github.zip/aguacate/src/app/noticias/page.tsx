import { prisma } from "@/lib/prisma";
import Link from "next/link";
import Image from "next/image";
import { Badge } from "@/components/ui/Badge";
import { formatRelativeDate } from "@/lib/utils";
import { Newspaper } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Noticias" };
export const revalidate = 60;

const CATEGORY_LABELS: Record<string, string> = {
  GENERAL: "General", VALORANT: "Valorant", SMASH: "Smash",
  TEKKEN: "Tekken", STREET_FIGHTER: "Street Fighter",
  ROCKET_LEAGUE: "Rocket League", FC: "EA FC",
  COMMUNITY: "Comunidad", ANNOUNCEMENT: "Anuncio",
};

export default async function NoticiasPage({
  searchParams,
}: {
  searchParams: Promise<{ cat?: string }>;
}) {
  const { cat } = await searchParams;

  const noticias = await prisma.news.findMany({
    where: {
      published: true,
      ...(cat ? { category: cat as never } : {}),
    },
    include: { author: { select: { name: true, image: true, username: true } } },
    orderBy: [{ featured: "desc" }, { publishedAt: "desc" }],
    take: 30,
  }).catch(() => []);

  const categories = Object.entries(CATEGORY_LABELS);

  return (
    <div className="py-10">
      <div className="container-aguacate">
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
            — Contenido
          </p>
          <h1 className="font-display text-4xl md:text-5xl text-white">NOTICIAS</h1>
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          <Link
            href="/noticias"
            className={`px-3.5 py-1.5 rounded-full text-sm font-body border transition-all ${
              !cat
                ? "bg-brand-blue/15 border-brand-blue/30 text-white font-semibold"
                : "border-surface-border text-text-secondary hover:text-white hover:border-white/20"
            }`}
          >
            Todas
          </Link>
          {categories.map(([value, label]) => (
            <Link
              key={value}
              href={`/noticias?cat=${value}`}
              className={`px-3.5 py-1.5 rounded-full text-sm font-body border transition-all ${
                cat === value
                  ? "bg-brand-blue/15 border-brand-blue/30 text-white font-semibold"
                  : "border-surface-border text-text-secondary hover:text-white hover:border-white/20"
              }`}
            >
              {label}
            </Link>
          ))}
        </div>

        {noticias.length === 0 ? (
          <div className="text-center py-20">
            <Newspaper size={40} className="text-text-muted mx-auto mb-4" />
            <p className="font-display text-xl text-white mb-2">Sin noticias</p>
            <p className="text-text-secondary text-sm font-body">Vuelve más tarde.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {noticias.map((noticia, idx) => (
              <NoticiaCard key={noticia.id} noticia={noticia} large={idx === 0 && !cat} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function NoticiaCard({ noticia, large }: { noticia: any; large?: boolean }) {
  return (
    <Link
      href={`/noticias/${noticia.slug}`}
      className={`group block ${large ? "md:col-span-2 lg:col-span-2" : ""}`}
    >
      <div
        className="rounded-xl border border-surface-border overflow-hidden h-full flex flex-col transition-all duration-200 hover:border-brand-blue/40 hover:-translate-y-0.5 hover:shadow-card-hover"
        style={{ background: "rgba(21,28,44,0.9)" }}
      >
        <div className={`relative overflow-hidden bg-surface-raised ${large ? "h-52" : "h-40"}`}>
          {noticia.image ? (
            <Image
              src={noticia.image}
              alt={noticia.title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div
              className="w-full h-full"
              style={{ background: "linear-gradient(135deg, rgba(0,87,184,0.2) 0%, rgba(10,13,20,0.8) 100%)" }}
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/60 to-transparent" />
          <div className="absolute top-3 left-3">
            <Badge variant="blue" className="text-[10px]">
              {CATEGORY_LABELS[noticia.category] ?? noticia.category}
            </Badge>
          </div>
        </div>

        <div className="p-4 flex flex-col flex-1">
          <h3
            className={`font-display text-white group-hover:text-brand-yellow transition-colors line-clamp-2 mb-2 ${large ? "text-lg" : "text-sm"}`}
          >
            {noticia.title}
          </h3>
          <p className="text-xs text-text-secondary font-body line-clamp-2 flex-1">
            {noticia.summary}
          </p>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-surface-border/50">
            <span className="text-xs text-text-muted font-body">
              {noticia.author?.name ?? "Redacción"}
            </span>
            <span className="text-xs text-text-muted font-body">
              {formatRelativeDate(noticia.publishedAt ?? noticia.createdAt)}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
