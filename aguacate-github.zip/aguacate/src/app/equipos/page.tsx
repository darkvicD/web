import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Users, Plus } from "lucide-react";
import { auth } from "@/lib/auth";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Equipos" };
export const revalidate = 60;

export default async function EquiposPage() {
  const session = await auth();

  const equipos = await prisma.team.findMany({
    where: { isActive: true },
    include: {
      _count: { select: { members: true, entries: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  }).catch(() => []);

  return (
    <div className="py-10">
      <div className="container-aguacate">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
              — Equipos
            </p>
            <h1 className="font-display text-4xl md:text-5xl text-white">EQUIPOS</h1>
          </div>
          {session && (
            <Link
              href="/equipos/crear"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-body font-bold transition-all"
              style={{ background: "#0057B8", color: "#FFFFFF" }}
            >
              <Plus size={15} />
              Crear Equipo
            </Link>
          )}
        </div>

        {equipos.length === 0 ? (
          <div className="text-center py-20">
            <Users size={40} className="text-text-muted mx-auto mb-4" />
            <p className="font-display text-xl text-white mb-2">No hay equipos</p>
            <p className="text-text-secondary text-sm font-body">Sé el primero en crear un equipo.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {equipos.map((equipo) => (
              <Link key={equipo.id} href={`/equipos/${equipo.slug}`} className="group block">
                <div
                  className="rounded-xl border border-surface-border overflow-hidden transition-all duration-200 hover:border-brand-blue/40 hover:-translate-y-0.5 hover:shadow-card-hover"
                  style={{ background: "rgba(21,28,44,0.9)" }}
                >
                  {/* Banner */}
                  <div
                    className="h-20 relative"
                    style={{
                      background: equipo.banner
                        ? `url(${equipo.banner}) center/cover`
                        : "linear-gradient(135deg, rgba(0,87,184,0.2) 0%, rgba(10,13,20,0.8) 100%)",
                    }}
                  />
                  <div className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="h-10 w-10 rounded-lg flex items-center justify-center font-display text-white text-sm font-bold flex-shrink-0 -mt-7 border-2 border-surface-border"
                        style={{
                          background: "linear-gradient(135deg, #0057B8, #003D80)",
                        }}
                      >
                        {equipo.tag}
                      </div>
                    </div>
                    <h3 className="font-display text-sm text-white group-hover:text-brand-yellow transition-colors truncate">
                      {equipo.name}
                    </h3>
                    <p className="text-xs text-text-muted font-body mt-1">
                      {equipo._count.members} miembros · {equipo._count.entries} torneos
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
