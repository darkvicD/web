import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { auth } from "@/lib/auth";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import Link from "next/link";
import { Users, Trophy, Crown, Shield, User } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { Metadata } from "next";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const team = await prisma.team.findUnique({ where: { slug }, select: { name: true } });
  return { title: team?.name ?? "Equipo" };
}

const ROLE_ICONS: Record<string, React.ComponentType<any>> = {
  OWNER: Crown,
  CAPTAIN: Shield,
  MEMBER: User,
};

const ROLE_LABELS: Record<string, string> = {
  OWNER: "Líder",
  CAPTAIN: "Capitán",
  MEMBER: "Miembro",
};

export default async function TeamPage({ params }: Props) {
  const { slug } = await params;
  const session = await auth();

  const team = await prisma.team.findUnique({
    where: { slug },
    include: {
      owner: { select: { name: true, image: true, username: true } },
      members: {
        include: {
          user: { select: { id: true, name: true, image: true, username: true } },
        },
        orderBy: { joinedAt: "asc" },
      },
      _count: { select: { entries: true } },
    },
  });

  if (!team) notFound();

  const isOwner = session?.user?.id === team.ownerId;
  const isMember = team.members.some((m) => m.userId === session?.user?.id);

  return (
    <div>
      {/* Banner */}
      <div
        className="h-48 md:h-60 relative"
        style={{
          background: team.banner
            ? `url(${team.banner}) center/cover`
            : "linear-gradient(135deg, rgba(0,87,184,0.25) 0%, rgba(10,13,20,0.9) 100%)",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-brand-bg/20 to-transparent" />
        <div
          className="absolute top-0 left-0 right-0 h-1"
          style={{ background: "linear-gradient(90deg, #0057B8, #FFD100)" }}
        />
      </div>

      <div className="container-aguacate">
        {/* Profile header */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-4 -mt-8 mb-8 relative z-10">
          <div
            className="h-20 w-20 rounded-2xl flex items-center justify-center font-display text-white text-2xl border-4 border-brand-bg flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #0057B8, #003D80)" }}
          >
            {team.tag}
          </div>
          <div className="flex-1 pb-1">
            <h1 className="font-display text-3xl text-white">{team.name}</h1>
            <p className="text-text-secondary font-body text-sm mt-0.5">
              [{team.tag}] · {team.members.length} miembros · {team._count.entries} torneos
            </p>
          </div>
          {isOwner && (
            <Link
              href={`/equipos/${slug}/editar`}
              className="px-4 py-2 rounded-lg text-sm font-body font-medium border border-surface-border text-text-secondary hover:text-white hover:border-white/20 transition-all"
            >
              Editar Equipo
            </Link>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pb-12">
          {/* Left */}
          <div className="lg:col-span-2 space-y-5">
            {team.description && (
              <Section title="Sobre el Equipo">
                <p className="text-text-secondary font-body text-sm leading-relaxed">
                  {team.description}
                </p>
              </Section>
            )}

            {/* Members */}
            <Section title={`Miembros (${team.members.length})`}>
              <div className="space-y-2">
                {team.members.map((member) => {
                  const RoleIcon = ROLE_ICONS[member.role] ?? User;
                  return (
                    <Link
                      key={member.id}
                      href={`/jugadores/${member.user.username ?? member.user.id}`}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/3 transition-colors group"
                    >
                      <Avatar src={member.user.image} name={member.user.name} size="sm" />
                      <div className="flex-1 min-w-0">
                        <p className="font-body font-semibold text-sm text-white group-hover:text-brand-yellow transition-colors truncate">
                          {member.user.name}
                        </p>
                        {member.user.username && (
                          <p className="text-xs text-text-muted font-body">@{member.user.username}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-text-muted font-body flex-shrink-0">
                        <RoleIcon size={12} />
                        {ROLE_LABELS[member.role]}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </Section>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Stats */}
            <div
              className="rounded-xl border border-surface-border p-5"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              <h3 className="font-display text-sm text-white uppercase tracking-wide mb-4">
                Estadísticas
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <StatBox icon={<Users size={14} />} value={team.members.length} label="Miembros" />
                <StatBox icon={<Trophy size={14} />} value={team._count.entries} label="Torneos" />
              </div>
            </div>

            {/* Since */}
            <div
              className="rounded-xl border border-surface-border p-4"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              <p className="text-xs text-text-muted font-body">Creado el</p>
              <p className="font-body text-sm text-white mt-0.5">{formatDate(team.createdAt)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-surface-border p-5" style={{ background: "rgba(15,20,32,0.9)" }}>
      <h2 className="font-display text-base text-white mb-4 pb-3 border-b border-surface-border">{title}</h2>
      {children}
    </div>
  );
}

function StatBox({ icon, value, label }: { icon: React.ReactNode; value: number; label: string }) {
  return (
    <div className="rounded-lg p-3 text-center" style={{ background: "rgba(21,28,44,0.8)" }}>
      <div className="flex items-center justify-center text-text-muted mb-1">{icon}</div>
      <p className="font-display text-xl text-white">{value}</p>
      <p className="text-xs text-text-muted font-body">{label}</p>
    </div>
  );
}
