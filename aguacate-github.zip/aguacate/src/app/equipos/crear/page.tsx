"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import toast from "react-hot-toast";

export default function CrearEquipoPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: "",
    tag: "",
    description: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.tag.length < 2 || form.tag.length > 8) {
      toast.error("El tag debe tener entre 2 y 8 caracteres");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/equipos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error ?? "Error al crear equipo");
        return;
      }
      const { slug } = await res.json();
      toast.success("¡Equipo creado!");
      router.push(`/equipos/${slug}`);
    } catch {
      toast.error("Error de conexión");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-10">
      <div className="container-aguacate max-w-lg">
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
            — Equipos
          </p>
          <h1 className="font-display text-3xl text-white">CREAR EQUIPO</h1>
        </div>

        <div
          className="rounded-2xl border border-surface-border p-6"
          style={{ background: "rgba(15,20,32,0.95)" }}
        >
          <form onSubmit={handleSubmit} className="space-y-5">
            <Input
              label="Nombre del Equipo"
              placeholder="Ej: Dark Warriors"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
            <Input
              label="Tag del Equipo (2-8 caracteres)"
              placeholder="Ej: DW"
              value={form.tag}
              maxLength={8}
              onChange={(e) =>
                setForm({ ...form, tag: e.target.value.toUpperCase() })
              }
              hint="Se mostrará como: DW NombreJugador"
              required
            />
            <div className="space-y-1.5">
              <label className="block text-sm font-body font-medium text-text-secondary">
                Descripción (opcional)
              </label>
              <textarea
                rows={3}
                placeholder="Cuéntanos sobre tu equipo..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full px-4 py-3 rounded-lg text-sm font-body text-white placeholder-text-muted border border-surface-border bg-surface outline-none focus:border-brand-blue focus:ring-1 focus:ring-brand-blue/20 transition-all resize-none"
              />
            </div>

            {/* Preview */}
            {(form.name || form.tag) && (
              <div
                className="rounded-lg border border-brand-blue/20 p-4 bg-brand-blue/5"
              >
                <p className="text-xs text-text-muted font-body mb-1.5 uppercase tracking-wider">
                  Vista previa
                </p>
                <div className="flex items-center gap-3">
                  <div
                    className="h-10 w-10 rounded-lg flex items-center justify-center font-display text-white text-sm"
                    style={{ background: "linear-gradient(135deg, #0057B8, #003D80)" }}
                  >
                    {form.tag || "??"}
                  </div>
                  <div>
                    <p className="font-display text-white text-sm">
                      {form.name || "Nombre del Equipo"}
                    </p>
                    <p className="text-xs text-text-muted font-body">
                      {form.tag || "TAG"} · 1 miembro
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => router.back()}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                variant="primary"
                loading={loading}
                className="flex-1"
              >
                Crear Equipo
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
