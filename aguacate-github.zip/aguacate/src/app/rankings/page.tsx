import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Avatar } from "@/components/ui/Avatar";
import { BarChart2, Medal } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Rankings" };
export const revalidate = 120;

export default async function RankingsPage() {
  const [games, topGlobal] = await Promise.all([
    prisma.game.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }),
    prisma.ranking.findMany({
      orderBy: { points: "desc" },
      take: 20,
      include: {
        game: { select: { name: true, slug: true } },
      },
    }),
  ]).catch(() => [[], []]);

  // Group by user to create a global ranking
  const userMap = new Map<string, { userId: string; totalPoints: number; wins: number; matches: number }>();
  for (const r of topGlobal as any[]) {
    const prev = userMap.get(r.userId) ?? { userId: r.userId, totalPoints: 0, wins: 0, matches: 0 };
    userMap.set(r.userId, {
      userId: r.userId,
      totalPoints: prev.totalPoints + r.points,
      wins: prev.wins + r.wins,
      matches: prev.matches + r.matches,
    });
  }

  return (
    <div className="py-10">
      <div className="container-aguacate">
        {/* Header */}
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
            — Clasificación
          </p>
          <h1 className="font-display text-4xl md:text-5xl text-white">RANKINGS</h1>
        </div>

        {/* Game filter tabs */}
        {Array.isArray(games) && games.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            <Link
              href="/rankings"
              className="px-4 py-2 rounded-full text-sm font-body font-semibold border bg-brand-blue/15 border-brand-blue/30 text-white"
            >
              Global
            </Link>
            {games.map((g: any) => (
              <Link
                key={g.id}
                href={`/rankings/${g.slug}`}
                className="px-4 py-2 rounded-full text-sm font-body border border-surface-border text-text-secondary hover:text-white hover:border-white/20 transition-all"
              >
                {g.name}
              </Link>
            ))}
          </div>
        )}

        {/* Top 3 podium */}
        <GlobalRankingTable />

        <div className="mt-8 text-center text-sm text-text-muted font-body">
          Los rankings se actualizan al finalizar cada torneo.
        </div>
      </div>
    </div>
  );
}

async function GlobalRankingTable() {
  const rankings = await prisma.ranking.findMany({
    orderBy: { points: "desc" },
    take: 50,
    include: {
      game: { select: { name: true } },
    },
  }).catch(() => []);

  // Aggregate by user
  const userScores = new Map<string, { points: number; wins: number; matches: number; gameCount: number }>();
  for (const r of rankings) {
    const prev = userScores.get(r.userId) ?? { points: 0, wins: 0, matches: 0, gameCount: 0 };
    userScores.set(r.userId, {
      points: prev.points + r.points,
      wins: prev.wins + r.wins,
      matches: prev.matches + r.matches,
      gameCount: prev.gameCount + 1,
    });
  }

  const sorted = [...userScores.entries()]
    .sort(([, a], [, b]) => b.points - a.points)
    .slice(0, 20);

  if (sorted.length === 0) {
    return (
      <div className="text-center py-16">
        <BarChart2 size={36} className="text-text-muted mx-auto mb-3" />
        <p className="font-body text-text-secondary text-sm">
          El ranking se construirá cuando se jueguen torneos.
        </p>
      </div>
    );
  }

  return (
    <div
      className="rounded-xl border border-surface-border overflow-hidden"
      style={{ background: "rgba(15,20,32,0.9)" }}
    >
      {/* Header */}
      <div className="grid grid-cols-12 px-4 py-3 text-xs font-body font-semibold text-text-muted uppercase tracking-wider border-b border-surface-border">
        <span className="col-span-1">#</span>
        <span className="col-span-5">Jugador</span>
        <span className="col-span-2 text-right">Puntos</span>
        <span className="col-span-2 text-right">Victorias</span>
        <span className="col-span-2 text-right">Partidas</span>
      </div>

      {sorted.map(([userId, data], idx) => {
        const position = idx + 1;
        return (
          <RankingRow
            key={userId}
            position={position}
            userId={userId}
            points={data.points}
            wins={data.wins}
            matches={data.matches}
          />
        );
      })}
    </div>
  );
}

async function RankingRow({
  position,
  userId,
  points,
  wins,
  matches,
}: {
  position: number;
  userId: string;
  points: number;
  wins: number;
  matches: number;
}) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { name: true, image: true, username: true, teamTag: true },
  }).catch(() => null);

  const positionColor =
    position === 1
      ? "text-brand-yellow"
      : position === 2
      ? "text-white/70"
      : position === 3
      ? "text-[#CD7F32]"
      : "text-text-muted";

  return (
    <Link
      href={`/jugadores/${user?.username ?? userId}`}
      className="grid grid-cols-12 px-4 py-3.5 items-center hover:bg-white/3 transition-colors border-b border-surface-border/50 last:border-0 group"
    >
      <span className={`col-span-1 font-display text-sm ${positionColor}`}>
        {position <= 3 ? (
          <Medal size={16} className="inline" />
        ) : (
          position
        )}
      </span>
      <div className="col-span-5 flex items-center gap-3">
        <Avatar src={user?.image} name={user?.name} size="sm" />
        <div className="min-w-0">
          <p className="text-sm font-body font-semibold text-white group-hover:text-brand-yellow transition-colors truncate">
            {user?.teamTag ? `${user.teamTag} ` : ""}
            {user?.name ?? `Jugador ${userId.slice(0, 6)}`}
          </p>
          {user?.username && (
            <p className="text-xs text-text-muted font-body">@{user.username}</p>
          )}
        </div>
      </div>
      <span className="col-span-2 text-right font-display text-sm text-brand-blue">
        {points.toLocaleString()}
      </span>
      <span className="col-span-2 text-right font-body text-sm text-text-secondary">
        {wins}
      </span>
      <span className="col-span-2 text-right font-body text-sm text-text-secondary">
        {matches}
      </span>
    </Link>
  );
}
