import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Avatar } from "@/components/ui/Avatar";
import { Medal } from "lucide-react";
import type { Metadata } from "next";

interface Props {
  params: Promise<{ game: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { game } = await params;
  const g = await prisma.game.findUnique({ where: { slug: game }, select: { name: true } });
  return { title: `Ranking — ${g?.name ?? game}` };
}

export default async function GameRankingPage({ params }: Props) {
  const { game: gameSlug } = await params;

  const game = await prisma.game.findUnique({ where: { slug: gameSlug } });
  if (!game) notFound();

  const [rankings, games] = await Promise.all([
    prisma.ranking.findMany({
      where: { gameId: game.id },
      orderBy: { points: "desc" },
      take: 50,
    }),
    prisma.game.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }),
  ]);

  return (
    <div className="py-10">
      <div className="container-aguacate">
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
            — Clasificación
          </p>
          <h1 className="font-display text-4xl md:text-5xl text-white">
            RANKING · {game.name.toUpperCase()}
          </h1>
        </div>

        {/* Game tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          <Link href="/rankings" className="px-4 py-2 rounded-full text-sm font-body border border-surface-border text-text-secondary hover:text-white transition-all">
            Global
          </Link>
          {games.map((g) => (
            <Link
              key={g.id}
              href={`/rankings/${g.slug}`}
              className={`px-4 py-2 rounded-full text-sm font-body font-semibold border transition-all ${
                g.slug === gameSlug
                  ? "bg-brand-blue/15 border-brand-blue/30 text-white"
                  : "border-surface-border text-text-secondary hover:text-white hover:border-white/20"
              }`}
            >
              {g.name}
            </Link>
          ))}
        </div>

        {rankings.length === 0 ? (
          <div className="text-center py-16">
            <p className="font-body text-text-secondary text-sm">
              Sin datos de ranking para {game.name} todavía.
            </p>
          </div>
        ) : (
          <div className="rounded-xl border border-surface-border overflow-hidden" style={{ background: "rgba(15,20,32,0.9)" }}>
            <div className="grid grid-cols-12 px-4 py-3 text-xs font-body font-semibold text-text-muted uppercase tracking-wider border-b border-surface-border">
              <span className="col-span-1">#</span>
              <span className="col-span-5">Jugador</span>
              <span className="col-span-2 text-right">Puntos</span>
              <span className="col-span-2 text-right">W</span>
              <span className="col-span-2 text-right">L</span>
            </div>
            {rankings.map((r, idx) => (
              <GameRankRow key={r.id} ranking={r} position={idx + 1} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

async function GameRankRow({ ranking, position }: { ranking: any; position: number }) {
  const user = await prisma.user.findUnique({
    where: { id: ranking.userId },
    select: { name: true, image: true, username: true, teamTag: true },
  }).catch(() => null);

  const posClass = position === 1 ? "text-brand-yellow" : position === 2 ? "text-white/70" : position === 3 ? "text-[#CD7F32]" : "text-text-muted";

  return (
    <Link
      href={`/jugadores/${user?.username ?? ranking.userId}`}
      className="grid grid-cols-12 px-4 py-3.5 items-center hover:bg-white/3 transition-colors border-b border-surface-border/50 last:border-0 group"
    >
      <span className={`col-span-1 font-display text-sm ${posClass}`}>
        {position <= 3 ? <Medal size={16} className="inline" /> : position}
      </span>
      <div className="col-span-5 flex items-center gap-3">
        <Avatar src={user?.image} name={user?.name} size="sm" />
        <p className="text-sm font-body font-semibold text-white group-hover:text-brand-yellow transition-colors truncate">
          {user?.teamTag ? `${user.teamTag} ` : ""}
          {user?.name ?? `User ${ranking.userId.slice(0, 6)}`}
        </p>
      </div>
      <span className="col-span-2 text-right font-display text-sm text-brand-blue">{ranking.points.toLocaleString()}</span>
      <span className="col-span-2 text-right font-body text-sm text-green-400">{ranking.wins}</span>
      <span className="col-span-2 text-right font-body text-sm text-red-400">{ranking.losses}</span>
    </Link>
  );
}
