import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Badge } from "@/components/ui/Badge";
import {
  getTournamentStatusColor,
  getTournamentStatusLabel,
  formatDate,
} from "@/lib/utils";
import { Trophy, Users, CalendarDays, Filter, Search } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Torneos",
  description: "Todos los torneos esports de República Dominicana.",
};

export const revalidate = 30;

const STATUS_FILTERS = [
  { value: "", label: "Todos" },
  { value: "REGISTRATION_OPEN", label: "Inscripciones Abiertas" },
  { value: "CHECK_IN", label: "Check-In" },
  { value: "IN_PROGRESS", label: "En Progreso" },
  { value: "COMPLETED", label: "Completados" },
];

export default async function TorneosPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; game?: string; q?: string }>;
}) {
  const params = await searchParams;
  const { status, game, q } = params;

  const [torneos, games] = await Promise.all([
    prisma.tournament.findMany({
      where: {
        status: { notIn: status ? undefined : ["DRAFT"] },
        ...(status ? { status: status as never } : {}),
        ...(game ? { game: { slug: game } } : {}),
        ...(q
          ? { name: { contains: q, mode: "insensitive" } }
          : {}),
      },
      include: {
        game: true,
        _count: { select: { entries: true } },
      },
      orderBy: [{ featured: "desc" }, { startDate: "asc" }],
    }),
    prisma.game.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }),
  ]).catch(() => [[], []]);

  return (
    <div className="py-10">
      <div className="container-aguacate">
        {/* Header */}
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
            — Competencias
          </p>
          <h1 className="font-display text-4xl md:text-5xl text-white">TORNEOS</h1>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search
              size={15}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none"
            />
            <form>
              <input
                type="text"
                name="q"
                defaultValue={q}
                placeholder="Buscar torneos..."
                className="w-full pl-9 pr-4 py-2.5 rounded-lg text-sm font-body text-white placeholder-text-muted border border-surface-border focus:border-brand-blue focus:outline-none focus:ring-1 focus:ring-brand-blue/20 transition-all"
                style={{ background: "rgba(21,28,44,0.8)" }}
              />
            </form>
          </div>

          {/* Status filter */}
          <div className="flex flex-wrap gap-2">
            {STATUS_FILTERS.map((f) => (
              <Link
                key={f.value}
                href={`/torneos${f.value ? `?status=${f.value}` : ""}`}
                className={`px-3.5 py-2 rounded-lg text-xs font-body font-semibold transition-all duration-150 border ${
                  (status ?? "") === f.value
                    ? "bg-brand-blue/20 border-brand-blue/40 text-white"
                    : "bg-surface-raised border-surface-border text-text-secondary hover:text-white hover:border-white/20"
                }`}
              >
                {f.label}
              </Link>
            ))}
          </div>
        </div>

        {/* Game filter */}
        {Array.isArray(games) && games.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            <Link
              href="/torneos"
              className={`px-3 py-1.5 rounded-full text-xs font-body transition-all border ${
                !game
                  ? "bg-brand-yellow/15 border-brand-yellow/30 text-brand-yellow"
                  : "border-surface-border text-text-muted hover:text-white hover:border-white/15"
              }`}
            >
              Todos los juegos
            </Link>
            {games.map((g: { id: string; slug: string; name: string }) => (
              <Link
                key={g.id}
                href={`/torneos?game=${g.slug}`}
                className={`px-3 py-1.5 rounded-full text-xs font-body transition-all border ${
                  game === g.slug
                    ? "bg-brand-yellow/15 border-brand-yellow/30 text-brand-yellow"
                    : "border-surface-border text-text-muted hover:text-white hover:border-white/15"
                }`}
              >
                {g.name}
              </Link>
            ))}
          </div>
        )}

        {/* Count */}
        <p className="text-sm text-text-muted font-body mb-4">
          {Array.isArray(torneos) ? torneos.length : 0} torneos encontrados
        </p>

        {/* Grid */}
        {!Array.isArray(torneos) || torneos.length === 0 ? (
          <div className="text-center py-20">
            <Trophy size={40} className="text-text-muted mx-auto mb-4" />
            <p className="font-display text-xl text-white mb-2">
              No hay torneos disponibles
            </p>
            <p className="text-text-secondary font-body text-sm">
              Intenta con otros filtros o vuelve más tarde.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {torneos.map((torneo) => (
              <TorneoCardFull key={torneo.id} torneo={torneo} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TorneoCardFull({ torneo }: { torneo: any }) {
  const slotsPercent = Math.min(
    100,
    ((torneo._count?.entries ?? 0) / torneo.maxParticipants) * 100
  );

  return (
    <Link href={`/torneos/${torneo.slug}`} className="group block">
      <div
        className="rounded-xl border border-surface-border overflow-hidden transition-all duration-200 hover:border-brand-blue/40 hover:-translate-y-0.5 hover:shadow-card-hover h-full flex flex-col"
        style={{ background: "rgba(21,28,44,0.9)" }}
      >
        {/* Banner */}
        <div
          className="h-32 relative"
          style={{
            background: torneo.banner
              ? `url(${torneo.banner}) center/cover`
              : "linear-gradient(135deg, rgba(0,87,184,0.25) 0%, rgba(10,13,20,0.8) 100%)",
          }}
        >
          {torneo.featured && (
            <div
              className="absolute top-0 left-0 right-0 h-0.5"
              style={{ background: "linear-gradient(90deg, #0057B8, #FFD100)" }}
            />
          )}
          <div className="absolute top-3 left-3">
            <span
              className="px-2.5 py-0.5 rounded-full text-xs font-body font-bold"
              style={{
                background: "rgba(10,13,20,0.85)",
                border: "1px solid rgba(255,255,255,0.1)",
                backdropFilter: "blur(8px)",
                color: "#FFFFFF",
              }}
            >
              {torneo.game?.name}
            </span>
          </div>
          <div className="absolute top-3 right-3">
            <span
              className={`px-2.5 py-0.5 rounded-full text-xs font-body font-semibold ${getTournamentStatusColor(torneo.status)}`}
            >
              {getTournamentStatusLabel(torneo.status)}
            </span>
          </div>
          {torneo.isOnline && (
            <div className="absolute bottom-3 left-3">
              <span className="text-[10px] text-white/50 font-body uppercase tracking-wider">
                Online
              </span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col flex-1">
          <h3 className="font-display text-base text-white mb-1 line-clamp-2 group-hover:text-brand-yellow transition-colors">
            {torneo.name}
          </h3>

          {torneo.prizePool && (
            <p className="text-brand-yellow font-body font-bold text-sm mb-3">
              RD${torneo.prizePool.toLocaleString()} en premios
            </p>
          )}

          <div className="flex flex-wrap gap-3 text-xs text-text-muted font-body mt-auto">
            <span className="flex items-center gap-1">
              <CalendarDays size={11} />
              {formatDate(torneo.startDate)}
            </span>
            <span className="flex items-center gap-1">
              <Users size={11} />
              {torneo._count?.entries ?? 0}/{torneo.maxParticipants}
            </span>
          </div>

          {/* Slot progress */}
          <div className="mt-3">
            <div className="h-1 rounded-full bg-surface-border overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{
                  width: `${slotsPercent}%`,
                  background: slotsPercent >= 90
                    ? "linear-gradient(90deg, #FFD100, #FFDA33)"
                    : "linear-gradient(90deg, #0057B8, #60A5FA)",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
