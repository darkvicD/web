import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { Users } from "lucide-react";
import Link from "next/link";

interface Props {
  params: Promise<{ slug: string }>;
}

export default async function ParticipantesPage({ params }: Props) {
  const { slug } = await params;

  const torneo = await prisma.tournament.findUnique({
    where: { slug },
    select: { id: true, name: true, maxParticipants: true },
  });
  if (!torneo) notFound();

  const entries = await prisma.tournamentEntry.findMany({
    where: { tournamentId: torneo.id },
    include: {
      user: {
        select: { id: true, name: true, image: true, username: true, teamTag: true },
      },
      team: {
        select: { id: true, name: true, tag: true, logo: true, slug: true },
      },
    },
    orderBy: { registeredAt: "asc" },
  });

  return (
    <div className="container-aguacate py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-xl text-white">Participantes</h2>
        <span className="text-sm text-text-secondary font-body">
          {entries.length}/{torneo.maxParticipants} slots
        </span>
      </div>

      {entries.length === 0 ? (
        <div className="text-center py-16">
          <Users size={36} className="text-text-muted mx-auto mb-3" />
          <p className="font-body text-text-secondary text-sm">
            Aún no hay participantes inscritos.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {entries.map((entry, idx) => (
            <div
              key={entry.id}
              className="flex items-center gap-3 p-3.5 rounded-xl border border-surface-border transition-all hover:border-brand-blue/30"
              style={{ background: "rgba(21,28,44,0.7)" }}
            >
              <span className="text-xs text-text-muted font-display w-5 flex-shrink-0">
                {idx + 1}
              </span>
              {entry.team ? (
                <>
                  <div
                    className="h-9 w-9 rounded-lg flex items-center justify-center font-display text-white text-xs flex-shrink-0"
                    style={{ background: "rgba(0,87,184,0.2)", border: "1px solid rgba(0,87,184,0.3)" }}
                  >
                    {entry.team.tag}
                  </div>
                  <div className="min-w-0 flex-1">
                    <Link href={`/equipos/${entry.team.slug}`} className="font-body font-semibold text-sm text-white hover:text-brand-yellow transition-colors truncate block">
                      {entry.team.name}
                    </Link>
                    <p className="text-xs text-text-muted font-body">{entry.team.tag}</p>
                  </div>
                </>
              ) : entry.user ? (
                <>
                  <Avatar src={entry.user.image} name={entry.user.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <Link href={`/jugadores/${entry.user.username ?? entry.user.id}`} className="font-body font-semibold text-sm text-white hover:text-brand-yellow transition-colors truncate block">
                      {entry.user.teamTag
                        ? `${entry.user.teamTag} ${entry.user.name}`
                        : entry.user.name}
                    </Link>
                    {entry.user.username && (
                      <p className="text-xs text-text-muted font-body">@{entry.user.username}</p>
                    )}
                  </div>
                </>
              ) : null}
              {entry.checkedIn && (
                <Badge variant="success" dot className="flex-shrink-0 text-[10px]">
                  CI
                </Badge>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
