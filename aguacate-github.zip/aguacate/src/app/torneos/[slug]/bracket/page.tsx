import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import BracketViewer from "@/components/torneos/BracketViewer";

interface Props {
  params: Promise<{ slug: string }>;
}

export default async function BracketPage({ params }: Props) {
  const { slug } = await params;

  const torneo = await prisma.tournament.findUnique({
    where: { slug },
    select: { id: true, name: true, status: true, format: true },
  });
  if (!torneo) notFound();

  const rounds = await prisma.tournamentRound.findMany({
    where: { tournamentId: torneo.id },
    include: {
      matches: { orderBy: { matchNumber: "asc" } },
    },
    orderBy: { roundNumber: "asc" },
  });

  return (
    <div className="container-aguacate py-8">
      <h2 className="font-display text-xl text-white mb-6">Bracket</h2>
      <BracketViewer rounds={rounds} format={torneo.format} status={torneo.status} />
    </div>
  );
}
