import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { auth } from "@/lib/auth";
import {
  getTournamentStatusColor,
  getTournamentStatusLabel,
  formatDate,
  formatPrizePool,
} from "@/lib/utils";
import {
  Trophy,
  Users,
  CalendarDays,
  Globe,
  MapPin,
  ChevronRight,
  Clock,
  Gamepad2,
} from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import CheckInButton from "@/components/torneos/CheckInButton";
import type { Metadata } from "next";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const torneo = await prisma.tournament.findUnique({
    where: { slug },
    select: { name: true, description: true },
  });
  if (!torneo) return { title: "Torneo no encontrado" };
  return {
    title: torneo.name,
    description: torneo.description ?? `Torneo oficial en AGUACATE.`,
  };
}

export default async function TorneoDetailPage({ params }: Props) {
  const { slug } = await params;
  const session = await auth();

  const torneo = await prisma.tournament.findUnique({
    where: { slug },
    include: {
      game: true,
      prizes: { orderBy: { placement: "asc" } },
      _count: { select: { entries: true } },
      organizer: { select: { name: true, image: true, username: true } },
      organization: { select: { name: true, slug: true, logo: true } },
    },
  });

  if (!torneo) notFound();

  // Check if user is registered
  let isRegistered = false;
  let isCheckedIn = false;
  if (session?.user?.id) {
    const entry = await prisma.tournamentEntry.findUnique({
      where: {
        tournamentId_userId: {
          tournamentId: torneo.id,
          userId: session.user.id,
        },
      },
    });
    isRegistered = !!entry;
    isCheckedIn = entry?.checkedIn ?? false;
  }

  const slotsUsed = torneo._count.entries;
  const slotsTotal = torneo.maxParticipants;
  const slotsPercent = Math.min(100, (slotsUsed / slotsTotal) * 100);
  const isFull = slotsUsed >= slotsTotal;

  const subPages = [
    { href: `/torneos/${slug}`, label: "Información" },
    { href: `/torneos/${slug}/participantes`, label: "Participantes" },
    { href: `/torneos/${slug}/bracket`, label: "Bracket" },
    { href: `/torneos/${slug}/resultados`, label: "Resultados" },
  ];

  return (
    <div>
      {/* Hero Banner */}
      <div
        className="relative h-56 md:h-72 overflow-hidden"
        style={{
          background: torneo.banner
            ? `url(${torneo.banner}) center/cover`
            : "linear-gradient(135deg, rgba(0,87,184,0.35) 0%, rgba(10,13,20,0.95) 100%)",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-brand-bg/40 to-transparent" />
        {/* Top accent */}
        <div
          className="absolute top-0 left-0 right-0 h-1"
          style={{ background: "linear-gradient(90deg, #0057B8, #FFD100, #0057B8)" }}
        />
        <div className="absolute bottom-0 left-0 right-0 container-aguacate pb-6">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span
                  className="px-2.5 py-0.5 rounded-full text-xs font-body font-bold"
                  style={{
                    background: "rgba(10,13,20,0.85)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    color: "#FFFFFF",
                  }}
                >
                  {torneo.game.name}
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-body font-semibold ${getTournamentStatusColor(torneo.status)}`}
                >
                  {getTournamentStatusLabel(torneo.status)}
                </span>
                {torneo.featured && (
                  <Badge variant="yellow" dot>Destacado</Badge>
                )}
              </div>
              <h1 className="font-display text-2xl md:text-4xl text-white leading-tight">
                {torneo.name}
              </h1>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-nav */}
      <div
        className="border-b border-surface-border sticky top-16 z-30"
        style={{ background: "rgba(10,13,20,0.95)", backdropFilter: "blur(12px)" }}
      >
        <div className="container-aguacate">
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
            {subPages.map(({ href, label }) => (
              <Link
                key={href}
                href={href}
                className="px-4 py-3.5 text-sm font-body font-medium whitespace-nowrap border-b-2 border-transparent hover:text-white text-text-secondary hover:border-brand-blue/50 transition-all"
              >
                {label}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-aguacate py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            {torneo.description && (
              <Section title="Sobre el Torneo">
                <p className="text-text-secondary font-body text-sm leading-relaxed whitespace-pre-line">
                  {torneo.description}
                </p>
              </Section>
            )}

            {/* Rules */}
            {torneo.rules && (
              <Section title="Reglas">
                <p className="text-text-secondary font-body text-sm leading-relaxed whitespace-pre-line">
                  {torneo.rules}
                </p>
              </Section>
            )}

            {/* Prizes */}
            {torneo.prizes.length > 0 && (
              <Section title="Premios">
                <div className="space-y-2">
                  {torneo.prizes.map((prize) => (
                    <div
                      key={prize.id}
                      className="flex items-center justify-between p-3.5 rounded-lg border border-surface-border"
                      style={{ background: "rgba(21,28,44,0.6)" }}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`font-display text-sm w-8 h-8 rounded-lg flex items-center justify-center ${
                            prize.placement === 1
                              ? "bg-brand-yellow/15 text-brand-yellow"
                              : prize.placement === 2
                              ? "bg-white/10 text-white/70"
                              : "bg-brand-blue/10 text-brand-blue"
                          }`}
                        >
                          #{prize.placement}
                        </span>
                        <span className="font-body text-sm text-white">
                          {prize.description}
                        </span>
                      </div>
                      {prize.value && (
                        <span className="font-body font-bold text-sm text-brand-yellow">
                          {formatPrizePool(prize.value)}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </Section>
            )}
          </div>

          {/* Right: Sidebar */}
          <div className="space-y-4">
            {/* Registration CTA */}
            <div
              className="rounded-xl border border-surface-border p-5"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              {/* Slots */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm font-body mb-1.5">
                  <span className="text-text-secondary">
                    <Users size={13} className="inline mr-1.5" />
                    Participantes
                  </span>
                  <span className="text-white font-semibold">
                    {slotsUsed}/{slotsTotal}
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-surface-border overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${slotsPercent}%`,
                      background: isFull
                        ? "#EF4444"
                        : slotsPercent >= 80
                        ? "linear-gradient(90deg, #FFD100, #FFDA33)"
                        : "linear-gradient(90deg, #0057B8, #60A5FA)",
                    }}
                  />
                </div>
                {isFull && (
                  <p className="text-xs text-red-400 font-body mt-1">
                    Torneo lleno
                  </p>
                )}
              </div>

              {/* Register button */}
              {session ? (
                <CheckInButton
                  tournamentId={torneo.id}
                  isRegistered={isRegistered}
                  isCheckedIn={isCheckedIn}
                  registrationOpen={torneo.registrationOpen}
                  checkInOpen={torneo.checkInOpen}
                  isFull={isFull}
                />
              ) : (
                <Link
                  href="/login"
                  className="block w-full text-center py-3 rounded-lg text-sm font-body font-bold transition-all"
                  style={{
                    background: "#0057B8",
                    color: "#FFFFFF",
                    boxShadow: "0 0 16px rgba(0,87,184,0.3)",
                  }}
                >
                  Iniciar Sesión para Inscribirse
                </Link>
              )}
            </div>

            {/* Details card */}
            <div
              className="rounded-xl border border-surface-border p-5 space-y-4"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              <h3 className="font-display text-sm text-white uppercase tracking-wide">
                Detalles
              </h3>

              <DetailRow
                icon={<CalendarDays size={14} />}
                label="Fecha de Inicio"
                value={formatDate(torneo.startDate, "dd MMM yyyy · HH:mm")}
              />
              {torneo.endDate && (
                <DetailRow
                  icon={<Clock size={14} />}
                  label="Fecha de Cierre"
                  value={formatDate(torneo.endDate, "dd MMM yyyy")}
                />
              )}
              <DetailRow
                icon={<Gamepad2 size={14} />}
                label="Formato"
                value={torneo.format.replace(/_/g, " ")}
              />
              <DetailRow
                icon={torneo.isOnline ? <Globe size={14} /> : <MapPin size={14} />}
                label="Modalidad"
                value={torneo.isOnline ? "Online" : torneo.location ?? "Presencial"}
              />
              {torneo.prizePool && (
                <DetailRow
                  icon={<Trophy size={14} />}
                  label="Premio Total"
                  value={formatPrizePool(torneo.prizePool)}
                  valueClass="text-brand-yellow font-bold"
                />
              )}
            </div>

            {/* Organizer */}
            <div
              className="rounded-xl border border-surface-border p-5"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              <h3 className="font-display text-sm text-white uppercase tracking-wide mb-3">
                Organizador
              </h3>
              {torneo.organization ? (
                <Link
                  href={`/organizaciones/${torneo.organization.slug}`}
                  className="flex items-center gap-3 hover:opacity-80 transition-opacity"
                >
                  <div
                    className="h-10 w-10 rounded-lg flex items-center justify-center font-display text-white text-sm flex-shrink-0"
                    style={{ background: "rgba(0,87,184,0.2)", border: "1px solid rgba(0,87,184,0.3)" }}
                  >
                    {torneo.organization.name[0]}
                  </div>
                  <div>
                    <p className="font-body font-semibold text-sm text-white">
                      {torneo.organization.name}
                    </p>
                    <p className="text-xs text-text-muted font-body">Organización</p>
                  </div>
                  <ChevronRight size={14} className="text-text-muted ml-auto" />
                </Link>
              ) : (
                <div className="flex items-center gap-3">
                  <div
                    className="h-10 w-10 rounded-full flex items-center justify-center font-display text-white text-sm flex-shrink-0"
                    style={{ background: "rgba(0,87,184,0.2)" }}
                  >
                    {torneo.organizer.name?.[0] ?? "?"}
                  </div>
                  <div>
                    <p className="font-body font-semibold text-sm text-white">
                      {torneo.organizer.name}
                    </p>
                    <p className="text-xs text-text-muted font-body">Organizador</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-xl border border-surface-border p-5"
      style={{ background: "rgba(15,20,32,0.9)" }}
    >
      <h2 className="font-display text-base text-white mb-4 pb-3 border-b border-surface-border">
        {title}
      </h2>
      {children}
    </div>
  );
}

function DetailRow({
  icon,
  label,
  value,
  valueClass = "text-white",
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 text-sm font-body">
      <span className="flex items-center gap-1.5 text-text-muted flex-shrink-0">
        {icon}
        {label}
      </span>
      <span className={`text-right ${valueClass}`}>{value}</span>
    </div>
  );
}
