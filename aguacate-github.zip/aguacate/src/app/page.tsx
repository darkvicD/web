import { prisma } from "@/lib/prisma";
import HeroSection from "@/components/home/HeroSection";
import TorneosDestacados from "@/components/home/TorneosDestacados";
import JuegosSection from "@/components/home/JuegosSection";
import EstadisticasGlobales from "@/components/home/EstadisticasGlobales";
import NoticiasCarrusel from "@/components/home/NoticiasCarrusel";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "AGUACATE — Torneos Esports República Dominicana",
  description:
    "La plataforma de torneos esports de República Dominicana. Compite en Valorant, Smash, Tekken y más.",
};

export const revalidate = 60;

async function getData() {
  try {
    const [torneos, noticias, stats] = await Promise.all([
      prisma.tournament.findMany({
        where: {
          featured: true,
          status: { notIn: ["DRAFT", "CANCELLED"] },
        },
        include: {
          game: true,
          _count: { select: { entries: true } },
        },
        orderBy: { startDate: "asc" },
        take: 6,
      }),
      prisma.news.findMany({
        where: { published: true },
        include: {
          author: { select: { name: true, image: true, username: true } },
        },
        orderBy: { publishedAt: "desc" },
        take: 4,
      }),
      Promise.all([
        prisma.tournament.count({ where: { status: "COMPLETED" } }),
        prisma.user.count(),
        prisma.game.count({ where: { isActive: true } }),
        prisma.organization.count(),
      ]),
    ]);

    return {
      torneos,
      noticias,
      stats: {
        tournaments: stats[0],
        players: stats[1],
        games: stats[2],
        organizations: stats[3],
      },
    };
  } catch {
    return {
      torneos: [],
      noticias: [],
      stats: { tournaments: 52, players: 634, games: 6, organizations: 8 },
    };
  }
}

export default async function HomePage() {
  const { torneos, noticias, stats } = await getData();

  return (
    <>
      <HeroSection />
      <EstadisticasGlobales stats={stats} />
      <JuegosSection />
      {torneos.length > 0 && (
        <TorneosDestacados torneos={torneos as never} />
      )}
      {noticias.length > 0 && (
        <NoticiasCarrusel noticias={noticias as never} />
      )}

      {/* CTA Final */}
      <section className="py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 60% 60% at 50% 50%, rgba(0,87,184,0.18) 0%, transparent 70%)",
          }}
        />
        <div className="container-aguacate relative text-center">
          <p className="text-xs font-body font-bold text-brand-yellow uppercase tracking-widest mb-3">
            ¿Listo para competir?
          </p>
          <h2 className="font-display text-4xl md:text-5xl text-white mb-4">
            EMPIEZA HOY
          </h2>
          <p className="text-text-secondary font-body max-w-md mx-auto mb-8">
            Crea tu cuenta, forma tu equipo y participa en torneos oficiales de República Dominicana.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/register"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-body font-bold text-base"
              style={{
                background: "#0057B8",
                color: "#FFFFFF",
                boxShadow: "0 0 24px rgba(0,87,184,0.4)",
              }}
            >
              Crear Cuenta <ArrowRight size={16} />
            </Link>
            <Link
              href="/torneos"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-body font-semibold text-base text-white/70 hover:text-white border border-white/12 hover:border-white/25 transition-all"
            >
              Ver Torneos
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
