import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import Link from "next/link";
import { Trophy, Users, Star, CalendarDays, Award } from "lucide-react";
import { formatDate, formatPoints } from "@/lib/utils";
import type { Metadata } from "next";

interface Props {
  params: Promise<{ username: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { username } = await params;
  const user = await prisma.user.findFirst({
    where: { OR: [{ username }, { id: username }] },
    select: { name: true, username: true },
  });
  return { title: user?.name ?? "Jugador" };
}

export default async function PlayerPage({ params }: Props) {
  const { username } = await params;

  const user = await prisma.user.findFirst({
    where: { OR: [{ username }, { id: username }] },
    include: {
      teamMemberships: {
        include: {
          team: { select: { name: true, tag: true, slug: true } },
        },
        take: 1,
      },
      tournamentEntries: {
        include: {
          tournament: {
            select: {
              id: true,
              name: true,
              slug: true,
              status: true,
              startDate: true,
              game: { select: { name: true } },
            },
          },
        },
        orderBy: { registeredAt: "desc" },
        take: 10,
      },
      achievements: {
        include: { achievement: true },
        orderBy: { earnedAt: "desc" },
        take: 6,
      },
    },
  });

  if (!user) notFound();

  const currentTeam = user.teamMemberships[0]?.team;
  const displayName = currentTeam
    ? `${currentTeam.tag} ${user.name}`
    : user.name;

  const rankings = await prisma.ranking.findMany({
    where: { userId: user.id },
    include: { game: { select: { name: true, slug: true } } },
    orderBy: { points: "desc" },
  });

  const totalWins = rankings.reduce((acc, r) => acc + r.wins, 0);
  const totalMatches = rankings.reduce((acc, r) => acc + r.matches, 0);

  return (
    <div>
      {/* Banner */}
      <div
        className="h-44 md:h-56 relative"
        style={{
          background: user.banner
            ? `url(${user.banner}) center/cover`
            : "linear-gradient(135deg, rgba(0,87,184,0.2) 0%, rgba(10,13,20,0.9) 100%)",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-brand-bg/10 to-transparent" />
      </div>

      <div className="container-aguacate">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-4 -mt-10 mb-8 relative z-10">
          <Avatar
            src={user.image}
            name={user.name}
            size="xl"
            className="border-4 border-brand-bg ring-2 ring-brand-blue/30"
          />
          <div className="flex-1 pb-1">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              {currentTeam && (
                <Link href={`/equipos/${currentTeam.slug}`}>
                  <Badge variant="blue">{currentTeam.tag}</Badge>
                </Link>
              )}
              {user.role === "ADMIN" && (
                <Badge variant="yellow">Admin</Badge>
              )}
              {user.role === "ORGANIZER" && (
                <Badge variant="default">Organizador</Badge>
              )}
            </div>
            <h1 className="font-display text-3xl text-white">{displayName}</h1>
            {user.username && (
              <p className="text-text-secondary font-body text-sm">
                @{user.username}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2 pb-1">
            <div
              className="px-4 py-2 rounded-lg text-center"
              style={{ background: "rgba(255,209,0,0.08)", border: "1px solid rgba(255,209,0,0.2)" }}
            >
              <p className="font-display text-lg text-brand-yellow">
                {formatPoints(user.points)}
              </p>
              <p className="text-xs text-text-muted font-body">AGUACATE PTS</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pb-12">
          {/* Main */}
          <div className="lg:col-span-2 space-y-5">
            {/* Bio */}
            {user.bio && (
              <div
                className="rounded-xl border border-surface-border p-5"
                style={{ background: "rgba(15,20,32,0.9)" }}
              >
                <h2 className="font-display text-sm text-white uppercase tracking-wide mb-3">Sobre mí</h2>
                <p className="text-text-secondary font-body text-sm leading-relaxed">{user.bio}</p>
              </div>
            )}

            {/* Tournament history */}
            {user.tournamentEntries.length > 0 && (
              <div
                className="rounded-xl border border-surface-border p-5"
                style={{ background: "rgba(15,20,32,0.9)" }}
              >
                <h2 className="font-display text-sm text-white uppercase tracking-wide mb-4 pb-3 border-b border-surface-border">
                  Historial de Torneos
                </h2>
                <div className="space-y-2">
                  {user.tournamentEntries.map((entry) => (
                    <Link
                      key={entry.id}
                      href={`/torneos/${entry.tournament.slug}`}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/3 transition-colors group"
                    >
                      <div
                        className="h-8 w-8 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ background: "rgba(0,87,184,0.15)" }}
                      >
                        <Trophy size={14} className="text-brand-blue" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-body font-semibold text-sm text-white group-hover:text-brand-yellow transition-colors truncate">
                          {entry.tournament.name}
                        </p>
                        <p className="text-xs text-text-muted font-body">
                          {entry.tournament.game.name} · {formatDate(entry.tournament.startDate)}
                        </p>
                      </div>
                      <span
                        className={`text-xs font-body px-2 py-0.5 rounded-full flex-shrink-0 ${
                          entry.status === "WINNER"
                            ? "text-brand-yellow bg-brand-yellow/10"
                            : "text-text-muted bg-surface-overlay"
                        }`}
                      >
                        {entry.status === "WINNER" ? "🏆 Ganador" : entry.status}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Achievements */}
            {user.achievements.length > 0 && (
              <div
                className="rounded-xl border border-surface-border p-5"
                style={{ background: "rgba(15,20,32,0.9)" }}
              >
                <h2 className="font-display text-sm text-white uppercase tracking-wide mb-4 pb-3 border-b border-surface-border">
                  Logros
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {user.achievements.map((ua) => (
                    <div
                      key={ua.id}
                      className="rounded-lg p-3 text-center border border-surface-border"
                      style={{ background: "rgba(21,28,44,0.7)" }}
                    >
                      <p className="text-2xl mb-1">{ua.achievement.icon ?? "🏅"}</p>
                      <p className="font-body font-semibold text-xs text-white">{ua.achievement.name}</p>
                      <p className="text-[10px] text-text-muted font-body mt-0.5">
                        +{ua.achievement.points} pts
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Stats */}
            <div
              className="rounded-xl border border-surface-border p-5"
              style={{ background: "rgba(15,20,32,0.9)" }}
            >
              <h3 className="font-display text-sm text-white uppercase tracking-wide mb-4">Stats</h3>
              <div className="space-y-3">
                <StatRow icon={<Trophy size={13} />} label="Torneos" value={user.tournamentEntries.length} />
                <StatRow icon={<Star size={13} />} label="Victorias" value={totalWins} />
                <StatRow icon={<Users size={13} />} label="Partidas" value={totalMatches} />
                <StatRow
                  icon={<Award size={13} />}
                  label="Logros"
                  value={user.achievements.length}
                />
                <StatRow
                  icon={<CalendarDays size={13} />}
                  label="Miembro desde"
                  value={formatDate(user.createdAt)}
                  isText
                />
              </div>
            </div>

            {/* Rankings per game */}
            {rankings.length > 0 && (
              <div
                className="rounded-xl border border-surface-border p-5"
                style={{ background: "rgba(15,20,32,0.9)" }}
              >
                <h3 className="font-display text-sm text-white uppercase tracking-wide mb-4">Rankings</h3>
                <div className="space-y-2.5">
                  {rankings.map((r) => (
                    <div key={r.id} className="flex items-center justify-between text-sm font-body">
                      <span className="text-text-secondary">{r.game.name}</span>
                      <span className="text-brand-blue font-semibold">
                        {r.points.toLocaleString()} pts
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Team */}
            {currentTeam && (
              <Link href={`/equipos/${currentTeam.slug}`}>
                <div
                  className="rounded-xl border border-surface-border p-4 hover:border-brand-blue/30 transition-all"
                  style={{ background: "rgba(15,20,32,0.9)" }}
                >
                  <p className="text-xs text-text-muted font-body mb-2 uppercase tracking-wider">Equipo</p>
                  <div className="flex items-center gap-3">
                    <div
                      className="h-9 w-9 rounded-lg flex items-center justify-center font-display text-white text-xs"
                      style={{ background: "linear-gradient(135deg, #0057B8, #003D80)" }}
                    >
                      {currentTeam.tag}
                    </div>
                    <div>
                      <p className="font-display text-sm text-white">{currentTeam.name}</p>
                      <p className="text-xs text-text-muted font-body">[{currentTeam.tag}]</p>
                    </div>
                  </div>
                </div>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatRow({
  icon,
  label,
  value,
  isText = false,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  isText?: boolean;
}) {
  return (
    <div className="flex items-center justify-between text-sm font-body">
      <span className="flex items-center gap-1.5 text-text-muted">
        {icon}
        {label}
      </span>
      <span className={isText ? "text-white text-xs" : "text-white font-semibold"}>{value}</span>
    </div>
  );
}
