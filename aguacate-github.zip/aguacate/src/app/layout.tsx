import type { Metadata } from "next";
import { Russo_One, Chakra_Petch } from "next/font/google";
import "./globals.css";
import { SessionProvider } from "@/components/providers/SessionProvider";
import { Toaster } from "react-hot-toast";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { auth } from "@/lib/auth";

const russoOne = Russo_One({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-russo",
  display: "swap",
});

const chakraPetch = Chakra_Petch({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"],
  variable: "--font-chakra",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "AGUACATE — Plataforma de Torneos Esports RD",
    template: "%s | AGUACATE",
  },
  description:
    "La plataforma de torneos esports de República Dominicana. Compite, mejora tu ranking y domina la escena.",
  keywords: ["esports", "torneos", "gaming", "República Dominicana", "valorant", "smash", "tekken"],
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"),
  openGraph: {
    type: "website",
    locale: "es_DO",
    url: process.env.NEXT_PUBLIC_APP_URL,
    siteName: "AGUACATE",
    title: "AGUACATE — Plataforma de Torneos Esports RD",
    description: "Compite en torneos esports de República Dominicana.",
  },
  twitter: {
    card: "summary_large_image",
    title: "AGUACATE",
    description: "Plataforma de torneos esports RD",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  return (
    <html lang="es" className={`${russoOne.variable} ${chakraPetch.variable}`}>
      <body className="bg-brand-bg text-white font-body antialiased">
        <SessionProvider session={session}>
          {/* Background grid */}
          <div
            className="fixed inset-0 pointer-events-none z-0 opacity-100"
            style={{
              backgroundImage:
                "linear-gradient(rgba(0,87,184,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,87,184,0.04) 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }}
          />
          {/* Top blue line accent */}
          <div
            className="fixed top-0 left-0 right-0 h-px z-50"
            style={{
              background: "linear-gradient(90deg, transparent, #0057B8, #FFD100, #0057B8, transparent)",
            }}
          />
          <div className="relative z-10 flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: "#151C2C",
                color: "#FFFFFF",
                border: "1px solid #1E2A3A",
                fontFamily: "Chakra Petch, sans-serif",
              },
              success: {
                iconTheme: { primary: "#0057B8", secondary: "#FFFFFF" },
              },
              error: {
                iconTheme: { primary: "#EF4444", secondary: "#FFFFFF" },
              },
            }}
          />
        </SessionProvider>
      </body>
    </html>
  );
}
