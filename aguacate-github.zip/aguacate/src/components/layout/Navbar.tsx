"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Trophy,
  BarChart2,
  Users,
  Gamepad2,
  Newspaper,
  Gift,
  Menu,
  X,
  ChevronDown,
  LogOut,
  Settings,
  User,
  Shield,
} from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { cn } from "@/lib/utils";

const navLinks = [
  { href: "/torneos", label: "Torneos", icon: Trophy },
  { href: "/rankings", label: "Rankings", icon: BarChart2 },
  { href: "/equipos", label: "Equipos", icon: Users },
  { href: "/juegos", label: "Juegos", icon: Gamepad2 },
  { href: "/noticias", label: "Noticias", icon: Newspaper },
  { href: "/recompensas", label: "Recompensas", icon: Gift },
];

export default function Navbar() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const isActive = (href: string) =>
    href === "/" ? pathname === href : pathname.startsWith(href);

  return (
    <header className="sticky top-0 z-40 w-full">
      {/* Blur background */}
      <div
        className="absolute inset-0 backdrop-blur-xl"
        style={{ background: "rgba(10,13,20,0.85)" }}
      />
      <div
        className="absolute bottom-0 left-0 right-0 h-px"
        style={{
          background:
            "linear-gradient(90deg, transparent 0%, rgba(0,87,184,0.4) 30%, rgba(255,209,0,0.3) 70%, transparent 100%)",
        }}
      />

      <nav className="relative container-aguacate flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 flex-shrink-0">
          <div
            className="h-8 w-8 rounded-lg flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, #0057B8, #003D80)",
              boxShadow: "0 0 16px rgba(0,87,184,0.5)",
            }}
          >
            <span className="font-display text-white text-sm">AG</span>
          </div>
          <span className="font-display text-xl tracking-tight text-white">
            AGUACATE
          </span>
          <div
            className="hidden sm:flex items-center px-1.5 py-0.5 rounded text-[10px] font-body font-bold tracking-widest"
            style={{
              background: "rgba(255,209,0,0.12)",
              color: "#FFD100",
              border: "1px solid rgba(255,209,0,0.25)",
            }}
          >
            BETA
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "px-3.5 py-2 rounded-lg text-sm font-body font-medium transition-all duration-150",
                isActive(href)
                  ? "text-white bg-brand-blue/15 border border-brand-blue/25"
                  : "text-white/60 hover:text-white hover:bg-white/5"
              )}
            >
              {label}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {session ? (
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg border border-surface-border hover:border-brand-blue/30 transition-all duration-150 cursor-pointer"
                style={{ background: "rgba(21,28,44,0.8)" }}
              >
                <Avatar
                  src={session.user.image}
                  name={session.user.name}
                  size="xs"
                />
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-body font-semibold text-white leading-tight">
                    {session.user.username ?? session.user.name?.split(" ")[0]}
                  </p>
                  <p className="text-[10px] text-brand-yellow font-body leading-tight">
                    {session.user.points ?? 0} pts
                  </p>
                </div>
                <ChevronDown
                  size={14}
                  className={cn(
                    "text-white/40 transition-transform duration-150",
                    userMenuOpen && "rotate-180"
                  )}
                />
              </button>

              <AnimatePresence>
                {userMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 6, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 6, scale: 0.97 }}
                    transition={{ duration: 0.12 }}
                    className="absolute right-0 top-full mt-1.5 w-52 rounded-xl border border-surface-border overflow-hidden"
                    style={{ background: "#151C2C" }}
                  >
                    <div className="p-3 border-b border-surface-border">
                      <p className="text-xs text-text-muted font-body">
                        {session.user.email}
                      </p>
                    </div>
                    <div className="p-1">
                      <DropdownItem
                        href={`/jugadores/${session.user.username ?? session.user.id}`}
                        icon={User}
                        label="Mi Perfil"
                        onClick={() => setUserMenuOpen(false)}
                      />
                      <DropdownItem
                        href="/dashboard"
                        icon={Settings}
                        label="Dashboard"
                        onClick={() => setUserMenuOpen(false)}
                      />
                      {session.user.role === "ADMIN" && (
                        <DropdownItem
                          href="/admin"
                          icon={Shield}
                          label="Admin Panel"
                          onClick={() => setUserMenuOpen(false)}
                        />
                      )}
                    </div>
                    <div className="p-1 border-t border-surface-border">
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          signOut({ callbackUrl: "/" });
                        }}
                        className="flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer font-body"
                      >
                        <LogOut size={14} />
                        Cerrar Sesión
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="hidden sm:block px-4 py-2 rounded-lg text-sm font-body font-medium text-white/70 hover:text-white border border-white/10 hover:border-white/20 transition-all duration-150"
              >
                Iniciar Sesión
              </Link>
              <Link
                href="/register"
                className="px-4 py-2 rounded-lg text-sm font-body font-bold transition-all duration-200"
                style={{
                  background: "#0057B8",
                  color: "#FFFFFF",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                Registrarse
              </Link>
            </div>
          )}

          {/* Mobile menu toggle */}
          <button
            className="lg:hidden p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-surface-border overflow-hidden"
            style={{ background: "rgba(10,13,20,0.97)" }}
          >
            <div className="container-aguacate py-3 space-y-1">
              {navLinks.map(({ href, label, icon: Icon }) => (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-body font-medium transition-all duration-150",
                    isActive(href)
                      ? "text-white bg-brand-blue/15 border border-brand-blue/25"
                      : "text-white/60 hover:text-white hover:bg-white/5"
                  )}
                >
                  <Icon size={16} />
                  {label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function DropdownItem({
  href,
  icon: Icon,
  label,
  onClick,
}: {
  href: string;
  icon: React.ComponentType<{ size?: number }>;
  label: string;
  onClick?: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors font-body"
    >
      <Icon size={14} />
      {label}
    </Link>
  );
}
