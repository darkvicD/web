import Link from "next/link";
import { Twitter, Youtube, MessageSquare, Instagram } from "lucide-react";

const footerLinks = {
  Plataforma: [
    { href: "/torneos", label: "Torneos" },
    { href: "/rankings", label: "Rankings" },
    { href: "/equipos", label: "Equipos" },
    { href: "/juegos", label: "Juegos" },
  ],
  Comunidad: [
    { href: "/noticias", label: "Noticias" },
    { href: "/organizaciones", label: "Organizaciones" },
    { href: "/recompensas", label: "Recompensas" },
  ],
  Legal: [
    { href: "/terminos", label: "Términos de Uso" },
    { href: "/privacidad", label: "Privacidad" },
    { href: "/contacto", label: "Contacto" },
  ],
};

const socials = [
  { href: "#", icon: Twitter, label: "Twitter/X" },
  { href: "#", icon: MessageSquare, label: "Discord" },
  { href: "#", icon: Instagram, label: "Instagram" },
  { href: "#", icon: Youtube, label: "YouTube" },
];

export default function Footer() {
  return (
    <footer
      className="border-t border-surface-border mt-auto"
      style={{ background: "rgba(10,13,20,0.95)" }}
    >
      {/* Top accent line */}
      <div
        className="h-px w-full"
        style={{
          background:
            "linear-gradient(90deg, transparent 0%, #0057B8 30%, #FFD100 70%, transparent 100%)",
        }}
      />

      <div className="container-aguacate py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-flex items-center gap-2.5 mb-4">
              <div
                className="h-8 w-8 rounded-lg flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, #0057B8, #003D80)",
                }}
              >
                <span className="font-display text-white text-sm">AG</span>
              </div>
              <span className="font-display text-xl text-white">AGUACATE</span>
            </Link>
            <p className="text-text-secondary text-sm font-body leading-relaxed max-w-xs mb-5">
              La plataforma de torneos esports de República Dominicana. Compite,
              rankea y domina la escena.
            </p>
            <div className="flex items-center gap-3">
              {socials.map(({ href, icon: Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="h-9 w-9 rounded-lg flex items-center justify-center text-white/40 hover:text-white hover:bg-brand-blue/20 border border-surface-border hover:border-brand-blue/30 transition-all duration-150"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-display text-sm text-white mb-4 tracking-wide">
                {category}
              </h4>
              <ul className="space-y-2.5">
                {links.map(({ href, label }) => (
                  <li key={href}>
                    <Link
                      href={href}
                      className="text-sm text-text-secondary hover:text-white font-body transition-colors duration-150"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-10 pt-6 border-t border-surface-border flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-text-muted font-body">
            © 2025 AGUACATE. Todos los derechos reservados. República Dominicana.
          </p>
          <div className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs text-text-muted font-body">
              Sistema operativo
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
