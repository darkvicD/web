"use client";

import { motion } from "framer-motion";
import { Trophy, Users, Gamepad2, Building2 } from "lucide-react";

interface StatsProps {
  stats?: {
    tournaments: number;
    players: number;
    games: number;
    organizations: number;
  };
}

const DEFAULT_STATS = {
  tournaments: 52,
  players: 634,
  games: 6,
  organizations: 8,
};

export default function EstadisticasGlobales({ stats = DEFAULT_STATS }: StatsProps) {
  const items = [
    {
      icon: Trophy,
      value: stats.tournaments,
      suffix: "+",
      label: "Torneos Realizados",
      color: "#0057B8",
    },
    {
      icon: Users,
      value: stats.players,
      suffix: "+",
      label: "Jugadores Registrados",
      color: "#FFD100",
    },
    {
      icon: Gamepad2,
      value: stats.games,
      suffix: "",
      label: "Títulos Activos",
      color: "#60A5FA",
    },
    {
      icon: Building2,
      value: stats.organizations,
      suffix: "+",
      label: "Organizaciones",
      color: "#94A3B8",
    },
  ];

  return (
    <section className="py-16 relative overflow-hidden">
      {/* BG accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 80% at 50% 50%, rgba(0,87,184,0.08) 0%, transparent 70%)",
        }}
      />

      <div className="container-aguacate relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {items.map(({ icon: Icon, value, suffix, label, color }, idx) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.08 }}
              className="rounded-xl border border-surface-border p-5 text-center transition-all duration-200 hover:border-brand-blue/30"
              style={{ background: "rgba(21,28,44,0.6)" }}
            >
              <div
                className="inline-flex items-center justify-center h-10 w-10 rounded-xl mb-3 mx-auto"
                style={{ background: `${color}15`, border: `1px solid ${color}30` }}
              >
                <Icon size={18} style={{ color }} />
              </div>
              <p
                className="font-display text-3xl md:text-4xl"
                style={{ color }}
              >
                {value}{suffix}
              </p>
              <p className="text-xs text-text-muted font-body mt-1 uppercase tracking-wider">
                {label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
