"use client";

import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { formatRelativeDate } from "@/lib/utils";
import type { NewsArticle } from "@/types";

interface NoticiasCarruselProps {
  noticias: NewsArticle[];
}

const CATEGORY_LABELS: Record<string, string> = {
  GENERAL: "General",
  VALORANT: "Valorant",
  SMASH: "Smash",
  TEKKEN: "Tekken",
  STREET_FIGHTER: "Street Fighter",
  ROCKET_LEAGUE: "Rocket League",
  FC: "EA FC",
  COMMUNITY: "Comunidad",
  ANNOUNCEMENT: "Anuncio",
};

export default function NoticiasCarrusel({ noticias }: NoticiasCarruselProps) {
  if (!noticias.length) return null;
  const [featured, ...rest] = noticias;

  return (
    <section className="py-16">
      <div className="container-aguacate">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
              — Noticias
            </p>
            <h2 className="font-display text-3xl md:text-4xl text-white">
              ÚLTIMAS NOTICIAS
            </h2>
          </div>
          <Link
            href="/noticias"
            className="hidden sm:inline-flex items-center gap-1.5 text-sm text-text-secondary hover:text-white font-body transition-colors"
          >
            Ver todas <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Featured */}
          <Link href={`/noticias/${featured.slug}`} className="group lg:col-span-2">
            <div
              className="rounded-xl border border-surface-border overflow-hidden transition-all duration-200 hover:border-brand-blue/40 hover:shadow-card-hover h-full"
              style={{ background: "rgba(21,28,44,0.8)" }}
            >
              <div className="relative h-52 md:h-64 overflow-hidden bg-surface-raised">
                {featured.image && (
                  <Image
                    src={featured.image}
                    alt={featured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/80 to-transparent" />
                <div className="absolute top-3 left-3">
                  <Badge variant="blue">
                    {CATEGORY_LABELS[featured.category] ?? featured.category}
                  </Badge>
                </div>
                {featured.featured && (
                  <div className="absolute top-3 right-3">
                    <Badge variant="yellow">Destacado</Badge>
                  </div>
                )}
              </div>
              <div className="p-5">
                <h3 className="font-display text-lg text-white mb-2 group-hover:text-brand-yellow transition-colors line-clamp-2">
                  {featured.title}
                </h3>
                <p className="text-sm text-text-secondary font-body line-clamp-2 mb-3">
                  {featured.summary}
                </p>
                <p className="text-xs text-text-muted font-body">
                  {formatRelativeDate(featured.publishedAt ?? featured.createdAt)}
                </p>
              </div>
            </div>
          </Link>

          {/* Side list */}
          <div className="flex flex-col gap-3">
            {rest.slice(0, 3).map((noticia) => (
              <Link
                key={noticia.id}
                href={`/noticias/${noticia.slug}`}
                className="group"
              >
                <div
                  className="flex gap-3 rounded-xl border border-surface-border overflow-hidden p-3.5 transition-all duration-200 hover:border-brand-blue/40"
                  style={{ background: "rgba(21,28,44,0.8)" }}
                >
                  {noticia.image && (
                    <div className="flex-shrink-0 h-16 w-20 rounded-lg overflow-hidden bg-surface-raised">
                      <Image
                        src={noticia.image}
                        alt={noticia.title}
                        width={80}
                        height={64}
                        className="object-cover w-full h-full"
                      />
                    </div>
                  )}
                  <div className="min-w-0">
                    <Badge variant="default" className="mb-1.5 text-[10px]">
                      {CATEGORY_LABELS[noticia.category] ?? noticia.category}
                    </Badge>
                    <h4 className="text-sm font-body font-semibold text-white group-hover:text-brand-yellow transition-colors line-clamp-2">
                      {noticia.title}
                    </h4>
                    <p className="text-xs text-text-muted font-body mt-1">
                      {formatRelativeDate(noticia.publishedAt ?? noticia.createdAt)}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
