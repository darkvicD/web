import Link from "next/link";
import { ArrowRight, Trophy, Users, CalendarDays } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { getTournamentStatusColor, getTournamentStatusLabel, formatDate } from "@/lib/utils";
import type { Tournament } from "@/types";

interface TorneosDestacadosProps {
  torneos: Tournament[];
}

export default function TorneosDestacados({ torneos }: TorneosDestacadosProps) {
  if (!torneos.length) return null;

  return (
    <section className="py-16">
      <div className="container-aguacate">
        {/* Section header */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-xs font-body font-bold text-brand-blue uppercase tracking-widest mb-2">
              — Competencias
            </p>
            <h2 className="font-display text-3xl md:text-4xl text-white">
              TORNEOS ACTIVOS
            </h2>
          </div>
          <Link
            href="/torneos"
            className="hidden sm:inline-flex items-center gap-1.5 text-sm text-text-secondary hover:text-white font-body transition-colors"
          >
            Ver todos <ArrowRight size={14} />
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {torneos.map((torneo, i) => (
            <TorneoCard key={torneo.id} torneo={torneo} featured={i === 0} />
          ))}
        </div>

        <div className="mt-6 sm:hidden">
          <Link
            href="/torneos"
            className="flex items-center justify-center gap-2 w-full py-3 rounded-lg text-sm text-text-secondary hover:text-white border border-surface-border hover:border-brand-blue/30 font-body transition-all"
          >
            Ver todos los torneos <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
}

function TorneoCard({
  torneo,
  featured,
}: {
  torneo: Tournament;
  featured: boolean;
}) {
  return (
    <Link href={`/torneos/${torneo.slug}`} className="group block">
      <div
        className={`
          rounded-xl border border-surface-border overflow-hidden transition-all duration-200
          hover:border-brand-blue/40 hover:-translate-y-0.5 hover:shadow-card-hover
          ${featured ? "md:col-span-2 lg:col-span-1" : ""}
        `}
        style={{
          background: "linear-gradient(135deg, rgba(21,28,44,0.9) 0%, rgba(10,13,20,0.9) 100%)",
        }}
      >
        {/* Banner */}
        <div
          className="h-36 relative overflow-hidden"
          style={{
            background: torneo.banner
              ? `url(${torneo.banner}) center/cover`
              : "linear-gradient(135deg, rgba(0,87,184,0.3) 0%, rgba(10,13,20,0.8) 100%)",
          }}
        >
          {/* Game badge */}
          <div className="absolute top-3 left-3">
            <span
              className="px-2.5 py-1 rounded-full text-xs font-body font-bold uppercase tracking-wider"
              style={{
                background: "rgba(10,13,20,0.8)",
                border: "1px solid rgba(255,255,255,0.12)",
                color: "#FFFFFF",
                backdropFilter: "blur(8px)",
              }}
            >
              {torneo.game?.name ?? "Unknown"}
            </span>
          </div>
          {/* Status badge */}
          <div className="absolute top-3 right-3">
            <span
              className={`px-2.5 py-1 rounded-full text-xs font-body font-semibold ${getTournamentStatusColor(torneo.status)}`}
            >
              {getTournamentStatusLabel(torneo.status)}
            </span>
          </div>
          {/* Blue bar at bottom */}
          <div
            className="absolute bottom-0 left-0 right-0 h-1 group-hover:opacity-100 opacity-0 transition-opacity"
            style={{ background: "linear-gradient(90deg, #0057B8, #FFD100)" }}
          />
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-display text-base text-white mb-2 line-clamp-1 group-hover:text-brand-yellow transition-colors">
            {torneo.name}
          </h3>

          {/* Meta */}
          <div className="flex items-center gap-4 text-xs text-text-muted font-body">
            <span className="flex items-center gap-1.5">
              <Users size={11} />
              {torneo._count?.entries ?? 0}/{torneo.maxParticipants}
            </span>
            <span className="flex items-center gap-1.5">
              <CalendarDays size={11} />
              {formatDate(torneo.startDate)}
            </span>
            {torneo.prizePool && (
              <span className="flex items-center gap-1 text-brand-yellow font-semibold">
                <Trophy size={11} />
                RD${torneo.prizePool.toLocaleString()}
              </span>
            )}
          </div>

          {/* Progress bar (slots) */}
          <div className="mt-3">
            <div className="h-1 rounded-full bg-surface-border overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    ((torneo._count?.entries ?? 0) / torneo.maxParticipants) * 100
                  )}%`,
                  background: "linear-gradient(90deg, #0057B8, #60A5FA)",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
