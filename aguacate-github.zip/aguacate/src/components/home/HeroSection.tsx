"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Trophy, ArrowRight, Zap } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-[92vh] flex items-center overflow-hidden">
      {/* Background layers */}
      <div
        className="absolute inset-0 z-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% -5%, rgba(0,87,184,0.30) 0%, transparent 65%)",
        }}
      />
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,87,184,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,87,184,0.06) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      {/* Diagonal accent line */}
      <div
        className="absolute top-0 left-0 right-0 bottom-0 z-0 pointer-events-none overflow-hidden"
        aria-hidden
      >
        <div
          className="absolute -right-40 top-10 h-[600px] w-[3px] rotate-[20deg]"
          style={{
            background:
              "linear-gradient(180deg, transparent 0%, #0057B8 30%, #FFD100 70%, transparent 100%)",
            opacity: 0.4,
          }}
        />
        <div
          className="absolute -right-20 top-10 h-[400px] w-[1px] rotate-[20deg]"
          style={{
            background:
              "linear-gradient(180deg, transparent 0%, rgba(0,87,184,0.5) 50%, transparent 100%)",
          }}
        />
      </div>

      <div className="container-aguacate relative z-10 py-20">
        <div className="max-w-3xl">
          {/* Pill badge */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-6 text-xs font-body font-bold tracking-widest uppercase"
            style={{
              background: "rgba(0,87,184,0.15)",
              border: "1px solid rgba(0,87,184,0.35)",
              color: "#60A5FA",
            }}
          >
            <Zap size={11} className="fill-current" />
            República Dominicana · Esports Platform
          </motion.div>

          {/* Main heading */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.08 }}
            className="font-display text-5xl md:text-6xl lg:text-7xl leading-[1.0] mb-6"
          >
            <span className="text-white">COMPITE.</span>
            <br />
            <span
              style={{
                background: "linear-gradient(135deg, #FFD100 0%, #FFFFFF 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              RANKEA.
            </span>
            <br />
            <span
              style={{
                background: "linear-gradient(135deg, #0057B8 0%, #60A5FA 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              DOMINA.
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="text-base md:text-lg text-white/60 font-body leading-relaxed max-w-xl mb-8"
          >
            La plataforma oficial de torneos esports de República Dominicana.
            Regístrate, únete a torneos, construye tu equipo y escala el ranking nacional.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.28 }}
            className="flex flex-wrap items-center gap-3"
          >
            <Link
              href="/torneos"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg font-body font-bold text-sm tracking-wide transition-all duration-200"
              style={{
                background: "#0057B8",
                color: "#FFFFFF",
                border: "1px solid rgba(255,255,255,0.1)",
                boxShadow: "0 0 20px rgba(0,87,184,0.35)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px rgba(0,87,184,0.6), 0 0 80px rgba(0,87,184,0.2)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 20px rgba(0,87,184,0.35)";
              }}
            >
              <Trophy size={16} />
              Ver Torneos
            </Link>
            <Link
              href="/register"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg font-body font-bold text-sm tracking-wide transition-all duration-200"
              style={{
                background: "#FFD100",
                color: "#0A0D14",
              }}
            >
              Crear Cuenta Gratis
              <ArrowRight size={15} />
            </Link>
          </motion.div>

          {/* Stats row */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="flex flex-wrap items-center gap-6 mt-12 pt-8 border-t border-white/8"
          >
            {[
              { value: "500+", label: "Jugadores" },
              { value: "50+", label: "Torneos" },
              { value: "6", label: "Juegos" },
              { value: "RD", label: "Solo local" },
            ].map(({ value, label }) => (
              <div key={label} className="text-center">
                <p className="font-display text-2xl text-white">{value}</p>
                <p className="text-xs text-text-muted font-body uppercase tracking-wider mt-0.5">
                  {label}
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Bottom fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-32 z-10 pointer-events-none"
        style={{
          background: "linear-gradient(0deg, #0A0D14 0%, transparent 100%)",
        }}
      />
    </section>
  );
}
