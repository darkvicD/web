import Link from "next/link";

const GAMES = [
  {
    slug: "valorant",
    name: "Valorant",
    emoji: "🎯",
    color: "#FF4655",
    tournaments: 12,
  },
  {
    slug: "smash",
    name: "Smash Ultimate",
    emoji: "⚔️",
    color: "#E4000F",
    tournaments: 8,
  },
  {
    slug: "tekken",
    name: "Tekken 8",
    emoji: "🥊",
    color: "#C41E3A",
    tournaments: 6,
  },
  {
    slug: "street-fighter",
    name: "Street Fighter 6",
    emoji: "👊",
    color: "#0057B8",
    tournaments: 5,
  },
  {
    slug: "rocket-league",
    name: "Rocket League",
    emoji: "🚀",
    color: "#0088CC",
    tournaments: 7,
  },
  {
    slug: "fc",
    name: "EA Sports FC",
    emoji: "⚽",
    color: "#00B140",
    tournaments: 9,
  },
];

export default function JuegosSection() {
  return (
    <section className="py-16">
      <div className="container-aguacate">
        <div className="mb-8">
          <p className="text-xs font-body font-bold text-brand-yellow uppercase tracking-widest mb-2">
            — Juegos
          </p>
          <h2 className="font-display text-3xl md:text-4xl text-white">
            TÍTULOS OFICIALES
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {GAMES.map((game) => (
            <Link
              key={game.slug}
              href={`/juegos/${game.slug}`}
              className="group block"
            >
              <div
                className="rounded-xl border border-surface-border overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:shadow-card-hover"
                style={{
                  background: "rgba(21,28,44,0.8)",
                }}
              >
                {/* Color stripe */}
                <div
                  className="h-1 w-full"
                  style={{ background: game.color, opacity: 0.7 }}
                />

                <div className="p-4 text-center">
                  <div className="text-3xl mb-2">{game.emoji}</div>
                  <p className="font-body font-semibold text-white text-xs leading-tight mb-1 group-hover:text-brand-yellow transition-colors">
                    {game.name}
                  </p>
                  <p className="text-[11px] text-text-muted font-body">
                    {game.tournaments} torneos
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
