"use client";

import { cn } from "@/lib/utils";
import { forwardRef } from "react";

type Variant = "primary" | "yellow" | "ghost" | "outline" | "danger";
type Size = "sm" | "md" | "lg" | "icon";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  children: React.ReactNode;
}

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-brand-blue hover:bg-[#0066D6] text-white border border-white/10 hover:shadow-blue-glow",
  yellow:
    "bg-brand-yellow hover:bg-[#FFDA33] text-brand-bg border border-white/15 hover:shadow-yellow-glow font-bold",
  ghost:
    "bg-transparent hover:bg-white/5 text-white/70 hover:text-white border border-white/12 hover:border-white/25",
  outline:
    "bg-transparent hover:bg-brand-blue/10 text-brand-blue border border-brand-blue/50 hover:border-brand-blue",
  danger:
    "bg-transparent hover:bg-red-500/10 text-red-400 border border-red-500/30 hover:border-red-500/60",
};

const sizeClasses: Record<Size, string> = {
  sm: "h-8 px-4 text-xs gap-1.5",
  md: "h-10 px-5 text-sm gap-2",
  lg: "h-12 px-7 text-base gap-2.5",
  icon: "h-10 w-10 p-0",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = "primary",
      size = "md",
      loading = false,
      className,
      children,
      disabled,
      ...props
    },
    ref
  ) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          "inline-flex items-center justify-center rounded-lg font-body font-semibold tracking-wide",
          "transition-all duration-200 cursor-pointer",
          "focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue/50",
          "disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none",
          "active:scale-[0.98]",
          variantClasses[variant],
          sizeClasses[size],
          className
        )}
        {...props}
      >
        {loading ? (
          <>
            <span className="h-4 w-4 rounded-full border-2 border-current border-t-transparent animate-spin" />
            <span>Cargando...</span>
          </>
        ) : (
          children
        )}
      </button>
    );
  }
);

Button.displayName = "Button";
