import { cn } from "@/lib/utils";

type BadgeVariant = "blue" | "yellow" | "success" | "error" | "default" | "outline";

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
  dot?: boolean;
}

const variantClasses: Record<BadgeVariant, string> = {
  blue: "bg-brand-blue/20 text-[#60A5FA] border-brand-blue/30",
  yellow: "bg-brand-yellow/10 text-brand-yellow border-brand-yellow/30",
  success: "bg-green-500/10 text-green-400 border-green-500/30",
  error: "bg-red-500/10 text-red-400 border-red-500/30",
  default: "bg-surface-overlay text-text-secondary border-surface-border",
  outline: "bg-transparent text-white/60 border-white/15",
};

export function Badge({ children, variant = "default", className, dot }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full",
        "text-xs font-body font-semibold tracking-wide border",
        variantClasses[variant],
        className
      )}
    >
      {dot && (
        <span
          className={cn(
            "h-1.5 w-1.5 rounded-full flex-shrink-0",
            variant === "blue" && "bg-[#60A5FA]",
            variant === "yellow" && "bg-brand-yellow",
            variant === "success" && "bg-green-400",
            variant === "error" && "bg-red-400",
            variant === "default" && "bg-text-muted",
            variant === "outline" && "bg-white/40"
          )}
        />
      )}
      {children}
    </span>
  );
}
