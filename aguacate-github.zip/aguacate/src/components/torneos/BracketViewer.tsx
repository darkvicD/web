"use client";

import { Swords } from "lucide-react";

interface Match {
  id: string;
  matchNumber: number;
  player1Id: string | null;
  player2Id: string | null;
  winnerId: string | null;
  player1Score: number | null;
  player2Score: number | null;
  status: string;
}

interface Round {
  id: string;
  roundNumber: number;
  name: string | null;
  isCompleted: boolean;
  matches: Match[];
}

interface Props {
  rounds: Round[];
  format: string;
  status: string;
}

export default function BracketViewer({ rounds, format, status }: Props) {
  if (rounds.length === 0) {
    return (
      <div className="text-center py-16">
        <Swords size={36} className="text-text-muted mx-auto mb-3" />
        <p className="font-display text-lg text-white mb-1">
          Bracket no disponible
        </p>
        <p className="text-sm text-text-secondary font-body">
          {status === "REGISTRATION_OPEN" || status === "CHECK_IN"
            ? "El bracket se generará cuando inicie el torneo."
            : "Este torneo aún no tiene bracket configurado."}
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex items-start gap-6 min-w-max">
        {rounds.map((round) => (
          <div key={round.id} className="flex flex-col gap-3">
            {/* Round header */}
            <div className="text-center mb-2">
              <p className="font-display text-sm text-white uppercase tracking-wider">
                {round.name ?? `Ronda ${round.roundNumber}`}
              </p>
              {round.isCompleted && (
                <span className="text-xs text-green-400 font-body">Completada</span>
              )}
            </div>

            {/* Matches */}
            <div className="flex flex-col gap-2">
              {round.matches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MatchCard({ match }: { match: Match }) {
  const isCompleted = match.status === "COMPLETED";

  return (
    <div
      className="w-52 rounded-lg border border-surface-border overflow-hidden"
      style={{ background: "rgba(21,28,44,0.9)" }}
    >
      <PlayerSlot
        playerId={match.player1Id}
        score={match.player1Score}
        isWinner={isCompleted && match.winnerId === match.player1Id}
      />
      <div className="h-px bg-surface-border" />
      <PlayerSlot
        playerId={match.player2Id}
        score={match.player2Score}
        isWinner={isCompleted && match.winnerId === match.player2Id}
      />
    </div>
  );
}

function PlayerSlot({
  playerId,
  score,
  isWinner,
}: {
  playerId: string | null;
  score: number | null;
  isWinner: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-between px-3 py-2 text-xs font-body transition-colors ${
        isWinner
          ? "bg-brand-blue/15 text-white"
          : "text-text-secondary"
      }`}
    >
      <span className="truncate flex-1">
        {playerId ? `Jugador ${playerId.slice(0, 6)}` : "TBD"}
      </span>
      {score !== null && (
        <span
          className={`font-bold ml-2 flex-shrink-0 ${
            isWinner ? "text-brand-yellow" : "text-text-muted"
          }`}
        >
          {score}
        </span>
      )}
    </div>
  );
}
