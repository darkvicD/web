"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import toast from "react-hot-toast";

interface Props {
  tournamentId: string;
  isRegistered: boolean;
  isCheckedIn: boolean;
  registrationOpen: boolean;
  checkInOpen: boolean;
  isFull: boolean;
}

export default function CheckInButton({
  tournamentId,
  isRegistered,
  isCheckedIn: initialCheckedIn,
  registrationOpen,
  checkInOpen,
  isFull,
}: Props) {
  const [registered, setRegistered] = useState(isRegistered);
  const [checkedIn, setCheckedIn] = useState(initialCheckedIn);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/torneos/${tournamentId}/register`, {
        method: "POST",
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error ?? "Error al inscribirse");
        return;
      }
      setRegistered(true);
      toast.success("¡Inscripción exitosa!");
    } catch {
      toast.error("Error de conexión");
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/torneos/${tournamentId}/checkin`, {
        method: "POST",
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error ?? "Error en el check-in");
        return;
      }
      setCheckedIn(true);
      toast.success("¡Check-in completado!");
    } catch {
      toast.error("Error de conexión");
    } finally {
      setLoading(false);
    }
  };

  if (checkedIn) {
    return (
      <div className="flex items-center justify-center gap-2 w-full py-3 rounded-lg text-sm font-body font-semibold text-green-400 bg-green-500/10 border border-green-500/25">
        <span className="h-2 w-2 rounded-full bg-green-400" />
        Check-In Completado
      </div>
    );
  }

  if (registered && checkInOpen) {
    return (
      <Button
        onClick={handleCheckIn}
        loading={loading}
        className="w-full"
        variant="yellow"
      >
        Hacer Check-In
      </Button>
    );
  }

  if (registered) {
    return (
      <div className="flex items-center justify-center gap-2 w-full py-3 rounded-lg text-sm font-body font-semibold text-brand-blue bg-brand-blue/10 border border-brand-blue/25">
        <span className="h-2 w-2 rounded-full bg-brand-blue" />
        Inscrito — Esperando Check-In
      </div>
    );
  }

  if (!registrationOpen) {
    return (
      <div className="flex items-center justify-center w-full py-3 rounded-lg text-sm font-body text-text-muted bg-surface-raised border border-surface-border">
        Inscripciones Cerradas
      </div>
    );
  }

  if (isFull) {
    return (
      <div className="flex items-center justify-center w-full py-3 rounded-lg text-sm font-body text-red-400 bg-red-500/10 border border-red-500/25">
        Torneo Lleno
      </div>
    );
  }

  return (
    <Button
      onClick={handleRegister}
      loading={loading}
      className="w-full"
      variant="primary"
    >
      Inscribirse
    </Button>
  );
}
