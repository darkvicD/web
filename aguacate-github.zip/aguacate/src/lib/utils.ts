import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { formatDistanceToNow, format } from "date-fns";
import { es } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string, pattern = "dd MMM yyyy") {
  return format(new Date(date), pattern, { locale: es });
}

export function formatRelativeDate(date: Date | string) {
  return formatDistanceToNow(new Date(date), { addSuffix: true, locale: es });
}

export function formatPoints(points: number): string {
  if (points >= 1000) return `${(points / 1000).toFixed(1)}K`;
  return points.toString();
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function getTournamentStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    DRAFT: "Borrador",
    REGISTRATION_OPEN: "Inscripciones Abiertas",
    CHECK_IN: "Check-In",
    IN_PROGRESS: "En Progreso",
    COMPLETED: "Completado",
    CANCELLED: "Cancelado",
  };
  return labels[status] ?? status;
}

export function getTournamentStatusColor(status: string): string {
  const colors: Record<string, string> = {
    DRAFT: "text-text-muted bg-surface-raised",
    REGISTRATION_OPEN: "text-state-success bg-state-success/10",
    CHECK_IN: "text-brand-yellow bg-brand-yellow/10",
    IN_PROGRESS: "text-brand-blue bg-brand-blue/20",
    COMPLETED: "text-text-secondary bg-surface-overlay",
    CANCELLED: "text-state-error bg-state-error/10",
  };
  return colors[status] ?? "text-text-secondary bg-surface-raised";
}

export function formatPrizePool(amount: number): string {
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    minimumFractionDigits: 0,
  }).format(amount);
}

export const GAME_ICONS: Record<string, string> = {
  valorant: "🎯",
  smash: "⚔️",
  tekken: "🥊",
  "street-fighter": "👊",
  "rocket-league": "🚀",
  fc: "⚽",
};

export const GAME_COLORS: Record<string, string> = {
  valorant: "#FF4655",
  smash: "#E4000F",
  tekken: "#C41E3A",
  "street-fighter": "#003087",
  "rocket-league": "#0088CC",
  fc: "#00B140",
};
