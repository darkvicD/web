import type { DefaultSession } from "next-auth";

// Extend NextAuth session types
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: string;
      username?: string;
      points?: number;
    } & DefaultSession["user"];
  }
}

// Game types
export interface Game {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  image?: string | null;
  banner?: string | null;
  icon?: string | null;
  isActive: boolean;
  sortOrder: number;
}

// Tournament types
export interface Tournament {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  banner?: string | null;
  logo?: string | null;
  gameId: string;
  game: Game;
  organizerId: string;
  format: TournamentFormat;
  status: TournamentStatus;
  region: string;
  maxParticipants: number;
  prizePool?: number | null;
  prizeDetails?: string | null;
  checkInOpen: boolean;
  registrationOpen: boolean;
  startDate: Date | string;
  endDate?: Date | string | null;
  featured: boolean;
  isOnline: boolean;
  location?: string | null;
  createdAt: Date | string;
  _count?: {
    entries: number;
  };
}

export type TournamentFormat =
  | "SINGLE_ELIMINATION"
  | "DOUBLE_ELIMINATION"
  | "ROUND_ROBIN"
  | "SWISS";

export type TournamentStatus =
  | "DRAFT"
  | "REGISTRATION_OPEN"
  | "CHECK_IN"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED";

// Team types
export interface Team {
  id: string;
  name: string;
  slug: string;
  tag: string;
  logo?: string | null;
  banner?: string | null;
  description?: string | null;
  isActive: boolean;
  ownerId: string;
  createdAt: Date | string;
  members?: TeamMember[];
  _count?: {
    members: number;
    entries: number;
  };
}

export interface TeamMember {
  id: string;
  userId: string;
  teamId: string;
  role: TeamRole;
  joinedAt: Date | string;
  user?: {
    id: string;
    name?: string | null;
    image?: string | null;
    username?: string | null;
  };
}

export type TeamRole = "OWNER" | "CAPTAIN" | "MEMBER";

// User/Profile types
export interface UserProfile {
  id: string;
  name?: string | null;
  email?: string | null;
  image?: string | null;
  username?: string | null;
  banner?: string | null;
  bio?: string | null;
  teamTag?: string | null;
  role: UserRole;
  points: number;
  createdAt: Date | string;
  teamMemberships?: TeamMember[];
  achievements?: UserAchievement[];
}

export type UserRole = "PLAYER" | "ORGANIZER" | "ADMIN";

// News types
export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  image?: string | null;
  category: NewsCategory;
  authorId: string;
  author?: {
    name?: string | null;
    image?: string | null;
    username?: string | null;
  };
  featured: boolean;
  published: boolean;
  publishedAt?: Date | string | null;
  createdAt: Date | string;
}

export type NewsCategory =
  | "GENERAL"
  | "VALORANT"
  | "SMASH"
  | "TEKKEN"
  | "STREET_FIGHTER"
  | "ROCKET_LEAGUE"
  | "FC"
  | "COMMUNITY"
  | "ANNOUNCEMENT";

// Achievement types
export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon?: string | null;
  points: number;
  condition: string;
}

export interface UserAchievement {
  id: string;
  userId: string;
  achievementId: string;
  earnedAt: Date | string;
  achievement: Achievement;
}

// Ranking types
export interface RankingEntry {
  id: string;
  userId: string;
  gameId: string;
  season: string;
  points: number;
  position?: number | null;
  wins: number;
  losses: number;
  matches: number;
  user?: UserProfile;
  game?: Game;
}

// Reward types
export interface Reward {
  id: string;
  name: string;
  description: string;
  image?: string | null;
  cost: number;
  stock?: number | null;
  category: RewardCategory;
  isActive: boolean;
}

export type RewardCategory = "DIGITAL" | "MERCH" | "ENTRY" | "EXCLUSIVE";

// Organization types
export interface Organization {
  id: string;
  name: string;
  slug: string;
  logo?: string | null;
  banner?: string | null;
  description?: string | null;
  website?: string | null;
  twitter?: string | null;
  discord?: string | null;
  isVerified: boolean;
  createdAt: Date | string;
}

// API Response types
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
