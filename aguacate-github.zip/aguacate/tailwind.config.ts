import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // AGUACATE Official Palette
        brand: {
          blue: "#0057B8",
          yellow: "#FFD100",
          white: "#FFFFFF",
          bg: "#0A0D14",
        },
        // Extended system
        surface: {
          DEFAULT: "#0F1420",
          raised: "#151C2C",
          overlay: "#1A2235",
          border: "#1E2A3A",
        },
        text: {
          primary: "#FFFFFF",
          secondary: "#94A3B8",
          muted: "#475569",
        },
        state: {
          success: "#22C55E",
          warning: "#FFD100",
          error: "#EF4444",
          info: "#0057B8",
        },
      },
      fontFamily: {
        display: ["var(--font-russo)", "Russo One", "sans-serif"],
        body: ["var(--font-chakra)", "Chakra Petch", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      fontSize: {
        "display-2xl": ["4.5rem", { lineHeight: "1", letterSpacing: "-0.02em" }],
        "display-xl": ["3.75rem", { lineHeight: "1", letterSpacing: "-0.02em" }],
        "display-lg": ["3rem", { lineHeight: "1.1", letterSpacing: "-0.01em" }],
        "display-md": ["2.25rem", { lineHeight: "1.2", letterSpacing: "-0.01em" }],
        "display-sm": ["1.875rem", { lineHeight: "1.3" }],
      },
      backgroundImage: {
        "grid-pattern":
          "linear-gradient(rgba(0,87,184,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(0,87,184,0.07) 1px, transparent 1px)",
        "hero-gradient":
          "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(0,87,184,0.35) 0%, transparent 60%)",
        "card-gradient":
          "linear-gradient(135deg, rgba(0,87,184,0.12) 0%, rgba(10,13,20,0) 100%)",
        "yellow-glow":
          "radial-gradient(ellipse 60% 40% at 50% 100%, rgba(255,209,0,0.2) 0%, transparent 70%)",
        "scan-lines":
          "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
      },
      backgroundSize: {
        grid: "40px 40px",
      },
      boxShadow: {
        "blue-glow": "0 0 20px rgba(0,87,184,0.4), 0 0 60px rgba(0,87,184,0.15)",
        "yellow-glow": "0 0 20px rgba(255,209,0,0.4), 0 0 60px rgba(255,209,0,0.15)",
        "card-hover": "0 8px 32px rgba(0,87,184,0.25), 0 2px 8px rgba(0,0,0,0.5)",
        "inner-border": "inset 0 1px 0 rgba(255,255,255,0.05)",
      },
      animation: {
        "fade-in": "fadeIn 0.5s ease-out",
        "slide-up": "slideUp 0.5s ease-out",
        "slide-in-right": "slideInRight 0.4s ease-out",
        "glow-pulse": "glowPulse 3s ease-in-out infinite",
        "scan": "scan 8s linear infinite",
        "ticker": "ticker 30s linear infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        slideInRight: {
          "0%": { opacity: "0", transform: "translateX(20px)" },
          "100%": { opacity: "1", transform: "translateX(0)" },
        },
        glowPulse: {
          "0%, 100%": { boxShadow: "0 0 20px rgba(0,87,184,0.3)" },
          "50%": { boxShadow: "0 0 40px rgba(0,87,184,0.6), 0 0 80px rgba(0,87,184,0.2)" },
        },
        scan: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
        ticker: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      borderRadius: {
        "4xl": "2rem",
      },
    },
  },
  plugins: [],
};

export default config;
